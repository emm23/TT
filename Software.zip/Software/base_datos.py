import mysql.connector
import datetime
from diccionario_escuelas import diccionario_escuelas
from logica_negocio import Buissnes_Builder

#from logica_negocio import Buissnes_Builder.mensaje

class Mysql_Builder:
    def __init__(self):
        self.config = {
        'user': 'root',
        'password': '12345678',
        'host': '127.0.0.1',
        'database': 'BD_TT1',
        'raise_on_warnings': True
        }

    def conexion(self):
        try:
            conexion=mysql.connector.connect(**self.config)
        except mysql.connector.Error as err:
            if(err.errno==1045):
                return 1045
            elif(err.errno==1049):
                return 1049
            elif(err.errno==2005):
                return 2005
        else:
            return conexion

    def agregar(self,conexion,accion,datos,**args):
        if("usuario" in accion):
            try:
                cursor=conexion.cursor(buffered=True)
                sql=("INSERT INTO Datos_empleado(Nombre,P_apellido,S_apellido,Empleado,Perfil,C_electronico) VALUES ('{}','{}','{}','{}','{}','{}')".format(datos.get("nombre"),datos.get("p_apellido"),datos.get("s_apellido"),datos.get("no_empleado"),datos.get("perfil"),datos.get("correo_e")))
                cursor.execute(sql)
                conexion.commit()
                id=cursor.lastrowid
                #print("ID")
                #print(id)
                sql2=("INSERT INTO Datos_usuario(Cuenta,Contrasena) VALUES ('{}','{}')".format(id,args['contrasena']))
                cursor.execute(sql2)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Empleado agregado"
        elif("herramienta" in accion):
            try:
                cursor=conexion.cursor()
                sql=("INSERT INTO Datos_herramientas(Herramienta,Categoria,Regla,Numero,Color) VALUES ('{}','{}','{}','{}','{}')".format(datos.get("herramienta"),datos.get("categoria"),datos.get("regla"),datos.get("numero"),datos.get("color")))
                cursor.execute(sql)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Regla agregada"

    def seleccionar(self,conexion,accion,**args):
        if("usuario" in accion):
            sql=("SELECT * FROM Datos_empleado")
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                resultado=cursor.fetchall()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado
        if("herramienta" in accion):
            sql=("SELECT * FROM Datos_herramientas")
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                resultado=cursor.fetchall()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado
        if("email" in accion):
            sql=("SELECT Correo_e FROM Datos_empleados WHERE ID_empleado='{}'".format(dato.split(',')[1]))
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                resultado=cursor.fetchone()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado
        if("cuestionario" in accion):
            sql=("SELECT Regla FROM Datos_herramientas")
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                resultado=cursor.fetchall()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return resultado
        if("clasificacion" in accion):
            sql=("SELECT ID_herramientas,Regla FROM Datos_herramientas WHERE Color <>'NA'")
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                resultado=cursor.fetchall()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return resultado
        if("denuncia" in accion):
            sql=("SELECT Datos_hechos.ID_hechos,Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido, Datos_denunciado.Nombre_d,Datos_denunciado.UA_DEP_d,Datos_hechos.F_denuncia,Datos_hechos.H_denuncia,Datos_clasificacion.ID_herramientas,Datos_clasificacion.Naive_bayes,Datos_herramientas.Herramienta,Datos_herramientas.Color,Datos_analisis.Estado from (((((Datos_hechos inner join Datos_denunciante on Datos_hechos.ID_denunciante=Datos_denunciante.ID_denunciante)inner join Datos_denunciado on Datos_hechos.ID_hechos=Datos_denunciado.ID_hechos)inner join Datos_clasificacion on Datos_hechos.ID_hechos=Datos_clasificacion.ID_hechos)inner join Datos_herramientas on Datos_clasificacion.ID_herramientas=Datos_herramientas.ID_herramientas)inner join Datos_analisis on Datos_hechos.ID_hechos=Datos_analisis.ID_hechos)")
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                resultado=cursor.fetchall()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado
        if("d_usr" in accion):
            resultado=list()
            sql=(("SELECT Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido,Datos_denunciante.F_nacimiento,Datos_denunciante.Edad,Datos_denunciante.Genero,Datos_denunciante.Otro_genero,Datos_denunciante.C_electronico,Datos_denunciante.T_celular,Datos_denunciante.T_fijo_ext,Datos_denunciante.Domicilio,Datos_academicos.UA_DEP,Datos_academicos.Turno,Datos_academicos.Perfil,Datos_academicos.Numero_boleta,Datos_academicos.Semestre,Datos_academicos.Grupo,Datos_academicos.Carrera,Datos_academicos.Numero_empleado,Datos_academicos.Nombre_superior,Datos_academicos.Descripcion,Datos_tutor.Nombre_completo,Datos_tutor.Edad_t,Datos_tutor.Genero_t,Datos_tutor.T_celular_t,Datos_tutor.T_fijo_ext_t,Datos_tutor.Domicilio_t,Datos_tutor.C_electronico_t,Datos_hechos.ID_hechos FROM (((Datos_hechos INNER JOIN Datos_denunciante ON Datos_hechos.ID_denunciante=Datos_denunciante.ID_denunciante) INNER JOIN Datos_academicos ON Datos_academicos.ID_hechos=Datos_hechos.ID_hechos) INNER JOIN Datos_tutor ON Datos_denunciante.ID_denunciante=Datos_tutor.ID_denunciante) WHERE Datos_hechos.ID_hechos='{}'").format(args["id"]),
            ("SELECT Nombre_d,UA_DEP_d,Turno_d,Perfil_d,Semestre_d,Grupo_d,Carrera_d,Puesto_d,Nombre_superior_d FROM Datos_denunciado WHERE ID_hechos='{}'").format(args["id"]),
            ("SELECT Anonimo,F_denuncia,H_denuncia,F_hechos,H_hechos,Lugar,Descripcion_hechos FROM Datos_hechos WHERE ID_hechos='{}'").format(args["id"]),
            ("SELECT Nombre_te,C_electronico_te,T_celular_te,T_fijo_ext_te FROM Datos_testigo WHERE ID_hechos='{}'").format(args["id"]),
            ("SELECT ID_denunciante,ID_hechos,Denuncia,Lista_evidencias,Archivos,Direccion_elec FROM Datos_pruebas WHERE ID_hechos='{}'").format(args["id"]),
            ("SELECT Estado,Confirmacion,Comentarios FROM Datos_analisis WHERE ID_hechos='{}'").format(args["id"]),
            )
            #print("Tipo de variable: ",type(sql))
            try:
                cursor=conexion.cursor(buffered=True)
                for i in sql:
                    #print("Query: ",i)
                    cursor.execute(i)
                    r=cursor.fetchall()
                    resultado.append(r)
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado
        if("estadisitcas" in accion):
            resultado=list()
            etiquetas=list()
            valores=list()
            #estadisticas de la denuncia
            sql0=("SELECT ID_denunciante,Nombre_d,UA_DEP_d,Perfil_d,Turno_d FROM Datos_denunciado WHERE ID_hechos='{}'").format(args['id'])
            #denuncias totales
            sql1=("SELECT COUNT(DISTINCT ID_hechos) FROM Datos_denunciado")
            #indicadores
            sql=(("SELECT COUNT(DISTINCT ID_hechos) FROM Datos_denunciado WHERE ID_denunciante='{}'  GROUP BY ID_denunciante"),
            ("SELECT COUNT(Nombre_d) FROM (SELECT DISTINCT ID_hechos,Nombre_d FROM Datos_denunciado)a WHERE Nombre_d='{}'"),
            ("SELECT COUNT(UA_DEP_d) FROM (SELECT DISTINCT ID_hechos,UA_DEP_d FROM Datos_denunciado)a WHERE UA_DEP_d='{}'"),
            ("SELECT COUNT(Perfil_d) FROM (SELECT DISTINCT ID_hechos,Perfil_d FROM Datos_denunciado)a WHERE Perfil_d='{}'"),
            ("SELECT COUNT(Turno_d) FROM (SELECT DISTINCT ID_hechos,Turno_d FROM Datos_denunciado)a WHERE Turno_d='{}'"))
            try:
                cursor=conexion.cursor(buffered=True)
                cursor.execute(sql0)
                busqueda=cursor.fetchall()
                #print("Busqueda: ",busqueda)
                for i in busqueda:
                    for j in range(len(i)):
                        aux=str(i[j])
                        if(aux not in etiquetas):
                            query=sql[j].format(aux)
                            #print(query,etiquetas)
                            cursor.execute(query)
                            r=cursor.fetchall()
                            etiquetas.append(aux)
                            valores.append(r[0][0])
                            #print(valores)
                cursor.execute(sql1)
                total=cursor.fetchall()
                resultado.append(etiquetas)
                resultado.append(valores)
                resultado.append(total[0][0])
                resultado.append(args['id'])
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado
        if("indicadores" in accion):
            resultado=list()
            #indicadores
            sql=(("SELECT COUNT(DISTINCT ID_hechos) FROM Datos_denunciado"),
            ("SELECT COUNT(DISTINCT ID_denunciante) FROM Datos_denunciado"),
            ("SELECT COUNT(ID_denunciado) FROM Datos_denunciado"),
            ("SELECT UA_DEP_d,COUNT(DISTINCT UA_DEP_d) FROM Datos_denunciado GROUP BY UA_DEP_d"),
            ("SELECT Perfil_d,COUNT(DISTINCT Perfil_d) FROM Datos_denunciado GROUP BY Perfil_d"),
            ("SELECT Turno_d,COUNT(Turno_d) FROM Datos_denunciado GROUP BY Turno_d"),
            ("SELECT F_denuncia,COUNT(ID_hechos) FROM Datos_hechos GROUP BY F_denuncia ORDER BY F_denuncia ASC"),
            ("SELECT F_hechos,COUNT(ID_hechos) FROM Datos_hechos GROUP BY F_hechos ORDER BY F_hechos ASC")
            )
            try:
                cursor=conexion.cursor(buffered=True)
                #print("Busqueda: ",busqueda)
                for i in sql:
                    cursor.execute(i)
                    r=cursor.fetchall()
                    resultado.append(r)
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado
        if("informacion" in accion):
            sql=("SELECT Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido,Datos_hechos.F_hechos,Datos_hechos.Lugar,Datos_hechos.Descripcion_hechos,Datos_denunciado.Nombre_d,Datos_denunciado.UA_DEP_d,Datos_denunciado.Turno_d,Datos_denunciado.Perfil_d,Datos_denunciado.Semestre_d,Datos_denunciado.Grupo_d,Datos_denunciado.Carrera_d,Datos_denunciado.Puesto_d,Datos_denunciado.Nombre_superior_d FROM ((Datos_hechos INNER JOIN Datos_denunciado ON Datos_denunciado.ID_hechos=Datos_hechos.ID_hechos)INNER JOIN Datos_denunciante ON Datos_denunciante.ID_denunciante=Datos_hechos.ID_hechos)")
            try:
                cursor=conexion.cursor(buffered=True)
                cursor.execute(sql)
                resultado=cursor.fetchall()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return resultado

    def seleccionar_info(self,conexion,*args):
        prueba=args[0]
        sql=("SELECT {},COUNT({}) FROM (Datos_hechos INNER JOIN Datos_denunciado ON Datos_denunciado.ID_hechos=Datos_hechos.ID_hechos) WHERE {} LIKE '%{}%' GROUP BY {}".
        format(prueba[0],prueba[0],prueba[1],prueba[2],prueba[0]))
        try:
            cursor=conexion.cursor(buffered=True)
            dc=cursor.execute(sql)
            resultado=cursor.fetchall()
            cursor.close()
        except mysql.connector.Error as err:
            return str(err)
        else:
            return resultado

    def eliminar(self,conexion,accion,dato):
        print(dato)
        if("usuario" in accion):
            sql="DELETE FROM Datos_empleado WHERE ID_empleado='{}'".format(dato)
            sql1="DELETE FROM Datos_usuario WHERE Cuenta='{}'".format(dato)
            try:
                cursor=conexion.cursor(buffered=True)
                cursor.execute(sql)
                conexion.commit()
                cursor.execute(sql1)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Empleado eliminado"
        if("herramienta" in accion):
            sql="DELETE FROM Datos_herramientas WHERE ID_herramientas='{}'".format(dato)
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Herramienta eliminada"

    def actualizar(self,conexion,accion,dato,**args):
        if("usuario" in accion):
            #UPDATE customers SET address = 'Canyon 123' WHERE address = 'Valley 345'
            sql=("UPDATE Datos_empleado SET Nombre='{}',P_apellido='{}',S_apellido='{}',Empleado='{}',Perfil='{}',C_electronico='{}' WHERE ID_empleado='{}'".
            format(dato.get("a_nombre"),dato.get("a_p_apellido"),dato.get("a_s_apellido"),int(dato.get("a_no_empleado")),dato.get("a_perfil"),dato.get("a_correo_e"),dato.get("id")))
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Empleado actualizado"
        if("herramienta" in accion):
            sql=("UPDATE Datos_herramientas SET Herramienta='{}',Categoria='{}',Regla='{}',Numero='{}',Color='{}' WHERE ID_herramientas='{}'".format(dato.get("a_herramienta"),dato.get("a_categoria"),dato.get("a_regla"),dato.get("a_numero"),dato.get("a_color"),dato.get("id")))
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Herramienta actualizada"
        if("contraseña" in accion):
            print("Actualizar"+accion,dato)
            sql=("UPDATE Datos_usuario SET Contrasena='{}' WHERE Cuenta='{}'".format(args['contrasena1'],dato))
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Contraseña actualizada"
        if("analisis" in accion):
            print("Actualizar"+accion,dato,args['id'],args['id_usr'])
            sql=("UPDATE Datos_analisis SET ID_usuario='{}',Estado='{}',Confirmacion='{}',Comentarios='{}' WHERE ID_hechos='{}'".format(args['id_usr'],dato.get("estado"),dato.get("confirmacion"),dato.get("comentario"),args['id']))
            try:
                cursor=conexion.cursor()
                cursor.execute(sql)
                conexion.commit()
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Análisis actualizado"

    def login(self,conexion,datos,**args):
        sql1="SELECT Datos_empleado.Perfil,Datos_empleado.ID_empleado FROM Datos_empleado INNER JOIN Datos_usuario WHERE Datos_empleado.ID_empleado=Datos_usuario.Cuenta AND Datos_empleado.C_electronico='{}' AND Datos_usuario.Contrasena='{}'".format(datos.get("correo_e"),args['contrasena'])
        try:
            cursor=conexion.cursor(buffered=True)
            cursor.execute(sql1)
            resultado=cursor.fetchone()
            print(resultado)
            cursor.close()
        except mysql.connector.Error as err:
            return str(err)
        else:
            return resultado

    def login_usr(self,conexion,datos,**args):
        sql1="SELECT Datos_denunciante.ID_denunciante,Datos_denunciante.Edad FROM Datos_denunciante INNER JOIN Datos_usuario WHERE Datos_denunciante.ID_denunciante=Datos_usuario.Cuenta AND Datos_denunciante.C_electronico='{}' AND Datos_usuario.Contrasena='{}'".format(datos.get("correo_e"),args['contrasena'])
        try:
            cursor=conexion.cursor(buffered=True)
            cursor.execute(sql1)
            resultado=cursor.fetchone()
            print(resultado)
            cursor.close()
        except mysql.connector.Error as err:
            return str(err)
        else:
            return resultado
    
    def registro_usr(self,conexion,accion,datos,**args):
        try:
            cursor=conexion.cursor(buffered=True)
            sql=("INSERT INTO Datos_denunciante(Nombre,P_apellido,S_apellido,F_nacimiento,Edad,Genero,Otro_genero,C_electronico,T_celular,T_fijo_ext,Domicilio) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(datos.get("den_nombre"),datos.get("den_p_apellido"),datos.get("den_s_apellido"),datos.get("den_f_nacimiento"),datos.get("den_edad"),datos.get("den_genero"),datos.get("den_otro"),datos.get("den_correo"),datos.get("den_t_celular"),datos.get("den_t_fijo"),datos.get("den_domicilio")))
            cursor.execute(sql)
            resultado=conexion.commit()
            id_denunciante=cursor.lastrowid
            #print("ID")
            #print(id)
            sql1=("INSERT INTO Datos_tutor(ID_denunciante,Nombre_completo,Edad_t,Genero_t,Otro_genero_t,T_celular_t,T_fijo_ext_t,Domicilio_t,C_electronico_t) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(id_denunciante,datos.get("tutor_nombre"),datos.get("tutor_edad"),datos.get("tutor_genero"),datos.get("tutor_o_genero"),datos.get("tutor_t_celular"),datos.get("tutor_t_fijo"),datos.get("tutor_domicilio"),datos.get("tutor_correo")))
            cursor.execute(sql1)
            dt=conexion.commit()
            print("tutor")
            print(dt)
            sql2=("INSERT INTO Datos_usuario(Cuenta,Contrasena) VALUES ('{}','{}')".format(id_denunciante,args['contrasena']))
            cursor.execute(sql2)
            conexion.commit()
            cursor.close()
        except mysql.connector.Error as err:
            return str(err)
        else:
            return "Correcto,Usuario agregado. Vuelve a iniciar sesión para entrar a su perfil."

    def cuestionario_usr(self,conexion,datos,**args):
        evidencias,rutas_archivos="",""
        id_denunciante=args['id']
        try:
            cursor=conexion.cursor(buffered=True)
            sql3=("INSERT INTO Datos_hechos(ID_denunciante,Anonimo,F_denuncia,H_denuncia,F_hechos,H_hechos,Lugar,Descripcion_hechos) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}')".format(id_denunciante,datos.get("hechos_anonimo"),datos.get("hechos_f_denuncia"),datos.get("hechos_h_denuncia"),datos.get("hechos_f_hechos"),datos.get("hechos_h_hechos"),datos.get("hechos_lugar"),datos.get("hechos_descripcion")))
            cursor.execute(sql3)
            r=conexion.commit()
            id_hechos=cursor.lastrowid
            print("hechos")
            print(r)
            sql1=("INSERT INTO Datos_academicos(ID_denunciante,ID_hechos,UA_DEP,Turno,Perfil,Numero_boleta,Semestre,Grupo,Carrera,Numero_empleado,Nombre_superior,Descripcion) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".
            format(id_denunciante,id_hechos,diccionario_escuelas[datos.get("aca_ua_dep")],datos.get("aca_turno"),datos.get("aca_perfil"),datos.get("aca_no_boleta"),datos.get("aca_semestre"),datos.get("aca_grupo"),datos.get("aca_carrera"),datos.get("aca_no_empleado"),datos.get("aca_nombre_jefe"),datos.get("aca_otro")))
            cursor.execute(sql1)
            da=conexion.commit()
            print("academico")
            print(da)
            #lista para denunciante
            print("denunciado")
            for i in range(len(datos.getlist("d_nombre[]"))):
                sql4=("INSERT INTO Datos_denunciado(ID_denunciante,ID_hechos,Nombre_d,UA_DEP_d,Turno_d,Perfil_d,Semestre_d,Grupo_d,Carrera_d,Puesto_d,Nombre_superior_d) VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".
                format(id_denunciante,id_hechos,datos.getlist("d_nombre[]")[i],diccionario_escuelas[datos.getlist("d_ua_dep[]")[i]],datos.getlist("d_turno[]")[i],datos.getlist("d_perfil[]")[i],datos.getlist("d_semestre[]")[i],datos.getlist("d_grupo[]")[i],datos.getlist("d_carrera[]")[i],datos.getlist("d_puesto[]")[i],datos.getlist("d_nombre_jefe[]")[i]))
                ce4=cursor.execute(sql4)
                dd=conexion.commit()
                print(dd)
            for i in range(len(datos.getlist("testigo_nombre[]"))):
                sql5=("INSERT INTO Datos_testigo(ID_denunciante,ID_hechos,Nombre_te,C_electronico_te,T_celular_te,T_fijo_ext_te) VALUES ('{}','{}','{}','{}','{}','{}')".
                format(id_denunciante,id_hechos,datos.getlist("testigo_nombre[]")[i],datos.getlist("testigo_correo[]")[i],datos.getlist("testigo_t_celular[]")[i],datos.getlist("testigo_t_fijo[]")[i]))
                cursor.execute(sql5)
                dt=conexion.commit()
                print("testigos")
                print(dt)
            #guardar archivos en servidor
            lg=Buissnes_Builder()
            l_archivos=datos.get("pruebas_l_evidencias")
            archivos=args["archivos"].getlist("pruebas_archivos[]")
            dir=datos.get("pruebas_d_electronica")
            if ("on" == str(datos.get("pruebas_denuncia"))):
                expediente=lg.crear_archivos(id_denunciante,id_hechos)
                guardararchivos=lg.guardar_archivo(archivos,expediente)
                for i in archivos:
                    ar=i.filename.replace(" ","")
                    evidencias+=ar+" "
                    rutas_archivos+=lg.crear_ruta_achivo(id_denunciante,id_hechos,ar)+" "
                print(evidencias)
                print(rutas_archivos)
            #pruebas
            sql9=("INSERT INTO Datos_pruebas(ID_denunciante,ID_hechos,Denuncia,Lista_evidencias,Archivos,Direccion_elec) VALUES ('{}','{}','{}','{}','{}','{}')".
            format(id_denunciante,id_hechos,datos.get("pruebas_denuncia"),evidencias,rutas_archivos,datos.get("pruebas_d_electronica")))
            cursor.execute(sql9)
            dp=conexion.commit()
            print("pruebas")
            print(dp)
            #clasificacion
            #seleccionamos el id de la herramienta con el del clasificador
            sel_her=("SELECT ID_herramientas FROM Datos_herramientas WHERE ID_herramientas='{}'").format(args['nb'])
            cursor.execute(sel_her)
            id_herramientas=cursor.fetchone()
            sql7=("INSERT INTO Datos_clasificacion(ID_hechos,ID_herramientas,Jaccard,Naive_bayes,Shallow,S_NN) VALUES ('{}','{}','{}','{}','{}','{}')".
            format(id_hechos,id_herramientas[0],args['jaccard'],args['nb'],args['shallow'],args['nn']))
            print(sql7)
            dcc=cursor.execute(sql7)
            dc=conexion.commit()
            id_clasificacion=cursor.lastrowid
            print("clasificacion")
            print(dcc)
            print(dc)
            sql8=("INSERT INTO Datos_analisis(ID_hechos,ID_usuario,ID_clasificacion,Estado,Confirmacion,Comentarios) VALUES ('{}','{}','{}','{}','{}','{}')".
            format(id_hechos,1,id_clasificacion,'Analisis','None','None'))
            print(sql8)
            daa=cursor.execute(sql8)
            da=conexion.commit()
            print("analisis")
            print(daa)
            print(da)
            cursor.close()
        except mysql.connector.Error as err:
            return str(err)
        return "Correcto,Denuncia registrada."

    def historial_usr(self,conexion,**args):
        #denuncia, hechos, analisis
        #SELECT ID_hechos,UA_DEP_d,F_denuncia,H_denuncia,Estado FROM denuncia INNER JOIN Datos_hechos ON denuncia.ID_hechos=Datos_hechos.ID_hechos AND Datos_hechos.ID_denunciante='{}'
        sql=("SELECT Datos_hechos.ID_hechos,Datos_denunciado.UA_DEP_d,Datos_hechos.F_denuncia,Datos_hechos.H_denuncia,Datos_analisis.Estado FROM ((Datos_hechos INNER JOIN Datos_analisis ON Datos_hechos.ID_hechos=Datos_analisis.ID_hechos)INNER JOIN Datos_denunciado ON Datos_denunciado.ID_hechos=Datos_hechos.ID_hechos) WHERE Datos_denunciado.ID_denunciante='{}'".
        format(args['id']))
        try:
            cursor=conexion.cursor()
            aux=cursor.execute(sql)
            resultado=cursor.fetchall()
            print("AUX: ",aux,"Resultado: ",resultado)
            cursor.close()
        except mysql.connector.Error as err:
            return str(err),0
        else:
            return "2",resultado

    def historial_usr_den(self,conexion,**args):
        resultado=list()
        sql=(("SELECT UA_DEP,Turno,Perfil,Numero_boleta,Semestre,Grupo,Carrera,Numero_empleado,Nombre_superior,Descripcion FROM Datos_academicos WHERE ID_hechos='{}'").format(args["id"]),
        ("SELECT Nombre_d,UA_DEP_d,Turno_d,Perfil_d,Semestre_d,Grupo_d,Carrera_d,Puesto_d,Nombre_superior_d FROM Datos_denunciado WHERE ID_hechos='{}'").format(args["id"]),
        ("SELECT Anonimo,F_denuncia,H_denuncia,F_hechos,H_hechos,Lugar,Descripcion_hechos FROM Datos_hechos WHERE ID_hechos='{}'").format(args["id"]),
        ("SELECT Nombre_te,C_electronico_te,T_celular_te,T_fijo_ext_te FROM Datos_testigo WHERE ID_hechos='{}'").format(args["id"]),
        ("SELECT Denuncia,Lista_evidencias,Archivos,Direccion_elec FROM Datos_pruebas WHERE ID_hechos='{}'").format(args["id"]),
        ("SELECT Estado FROM Datos_analisis WHERE ID_hechos='{}'").format(args["id"]),
        )
        #print("Tipo de variable: ",type(sql))
        try:
            cursor=conexion.cursor(buffered=True)
            for i in sql:
                #print("Query: ",i)
                cursor.execute(i)
                r=cursor.fetchall()
                resultado.append(r)
                print(r)
            print(resultado)
            cursor.close()
        except mysql.connector.Error as err:
            return str(err),0
        else:
            return "2",resultado

    def datos_usr(self,conexion,accion,**args):
        if("usuario_usr" in accion):
            resultado=list()
            """
            ("SELECT Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido,Datos_denunciante.F_nacimiento,Datos_denunciante.Edad,Datos_denunciante.Genero,Datos_denunciante.Otro_genero,Datos_denunciante.C_electronico,Datos_denunciante.T_celular,Datos_denunciante.T_fijo_ext,Datos_denunciante.Domicilio,Datos_tutor.Nombre_completo,Datos_tutor.Edad_t,Datos_tutor.Genero_t,Datos_tutor.Otro_genero_t,Datos_tutor.T_celular_t,Datos_tutor.T_fijo_ext_t,Datos_tutor.Domicilio_t,Datos_tutor.C_electronico_t FROM (Datos_denunciante INNER JOIN Datos_tutor ON Datos_denunciante.ID_denunciante=Datos_tutor.ID_denunciante) WHERE ID_denunciante='{}'".format(args['id']))
            """
            sql=(("SELECT Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido,Datos_denunciante.F_nacimiento,Datos_denunciante.Edad,Datos_denunciante.Genero,Datos_denunciante.Otro_genero,Datos_denunciante.C_electronico,Datos_denunciante.T_celular,Datos_denunciante.T_fijo_ext,Datos_denunciante.Domicilio FROM Datos_denunciante WHERE ID_denunciante='{}'".format(args['id'])),
            ("SELECT Datos_tutor.Nombre_completo,Datos_tutor.Edad_t,Datos_tutor.Genero_t,Datos_tutor.Otro_genero_t,Datos_tutor.T_celular_t,Datos_tutor.T_fijo_ext_t,Datos_tutor.Domicilio_t,Datos_tutor.C_electronico_t FROM Datos_tutor WHERE ID_denunciante='{}'".format(args['id']))
            )
            try:
                cursor=conexion.cursor(buffered=True)
                for i in sql:
                    aux=cursor.execute(i)
                    r=cursor.fetchall()
                    resultado.append(r)
                cursor.close()
            except mysql.connector.Error as err:
                return str(err),0
            else:
                return "2",resultado

    def actualizar_usr(self,conexion,accion,datos,**args):
        if("actualizar_usr" in accion):
            sql=("UPDATE Datos_denunciante SET Nombre='{}',P_apellido='{}',S_apellido='{}',F_nacimiento='{}',Edad='{}',Genero='{}',Otro_genero='{}',C_electronico='{}',T_celular='{}',T_fijo_ext='{}',Domicilio='{}' WHERE ID_denunciante='{}'".
            format(datos.get("den_nombre"),datos.get("den_p_apellido"),datos.get("den_s_apellido"),datos.get("den_f_nacimiento"),datos.get("den_edad"),datos.get("den_genero"),datos.get("den_otro"),datos.get("den_correo"),datos.get("den_t_celular"),datos.get("den_t_fijo"),datos.get("den_domicilio"),args['id']))
            sql1=("UPDATE Datos_tutor SET Nombre_completo='{}',Edad_t='{}',Genero_t='{}',Otro_genero_t='{}',T_celular_t='{}',T_fijo_ext_t='{}',Domicilio_t='{}',C_electronico_t='{}' WHERE ID_denunciante='{}'".
            format(datos.get("tutor_nombre"),datos.get("tutor_edad"),datos.get("tutor_genero"),datos.get("tutor_o_genero"),datos.get("tutor_t_celular"),datos.get("tutor_t_fijo"),datos.get("tutor_domicilio"),datos.get("tutor_correo"),args['id']))
            print(sql)
            try:
                cursor=conexion.cursor(buffered=True)
                cursor.execute(sql)
                r1=conexion.commit()
                cursor.execute(sql1)
                r2=conexion.commit()
                print("Resultados: ",r1,r2)
                cursor.close()
            except mysql.connector.Error as err:
                return str(err)
            else:
                return "Correcto,Usuario actualizado."

    def desconectar(self,c):
        try:
            c.close()
            print("Terminado")
        except mysql.connector.Error as err:
            print("Error {}".format(err.errno))

"""
cadena="Emmanuel"
p=Mysql_Builder()
c=p.conexion()
login=p.login1(c,'emergos12@gmail.com',2012630399)
print(login)
#p.desconectar(cursor)

sql=(("SELECT COUNT(DISTINCT ID_denunciante) FROM Datos_denunciado WHERE ID_denunciante='{}'").format(args['id']),
("SELECT COUNT(Nombre_d),Nombre_d FROM Datos_denunciado WHERE ID_denunciante='{}' GROUP BY Nombre_d").format(args['id']),
("SELECT COUNT(UA_DEP_d),UA_DEP_d FROM Datos_denunciado WHERE ID_denunciante='{}' GROUP BY UA_DEP_d").format(args['id']),
("SELECT COUNT(Perfil_d),Perfil_d FROM Datos_denunciado WHERE ID_denunciante='{}' GROUP BY Perfil_d").format(args['id']),
("SELECT COUNT(Turno_d),Turno_d FROM Datos_denunciado WHERE ID_denunciante='{}' GROUP BY Turno_d").format(args['id'])
)
"""
