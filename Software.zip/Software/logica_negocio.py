import os
import pickle
from re import X
import numpy as np
from numpy.lib.shape_base import tile
import plotly.express as exp
import sklearn as sk
import pandas as pd
import joblib 
import hashlib
import plotly.graph_objects as go
import plotly.offline as po
import plotly.io as pio
from diccionario_escuelas import diccionario_escuelas
from plotly.subplots import make_subplots
from nltk import *
from nltk import stem
from sklearn.naive_bayes import BernoulliNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neighbors import NearestNeighbors
from werkzeug.utils import secure_filename
from flask_weasyprint import HTML

EXTENSIONES=('mp3', 'avi', 'aac', 'mp4', 'mpeg', 'docx', 'doc', 'txt', 'pdf', 'jpg', 'gif', 'png')
RUTA_DIR="/Volumes/nuevo/Drive/Dropbox/escuela1/TT/Software/static/archivos/"
RUTA_AR="archivos/{}/{}/{}"
RUTA_GRAFICAS="/Volumes/nuevo/Drive/Dropbox/escuela1/TT/Software/static/archivos/graficas/{}"
RUTA_GRAFICAS_RELATIVO="archivos/graficas/{}"
CONTRASENA="12345678"
bolsa_palabras_hd_a_o=list()
bolsa_palabras_hd=list()
#bolsa_palabras_h_gen_dig
#modelo_entrenamiento
#modelo_prediccion

class Buissnes_Builder:
    def __init__(self):
        if (not os.path.exists(RUTA_DIR)):
            os.mkdir(RUTA_DIR)
        if (not os.path.exists(RUTA_GRAFICAS)):
            os.mkdir(RUTA_GRAFICAS)

    def mensaje(self,numero):
        print(numero,type(numero))
        if("int" in str(type(numero))):
            if(numero==1045):
                return "Error en las credenciales de acceso"
            elif(numero==1049):
                return "Error no se encuentra la base de datos"
            elif(numero==2005):
                return "Error en la direccion del host"
            elif(numero==2003):
                return "Error con la comunicacion de la base de datos"
            elif(numero==1054):
                return "Error datos no encontrados"
        else:
            return "Correcto"

#guardar bolsa de palabras
    def inicializar_variables(self,*args):
        bolsa_palabras_hd=args[0]
        print(bolsa_palabras_hd)
        bolsa_palabras_hd_a_o=args[1]
        with open("bolsa_palabras_hd.pickle", "wb") as f:
            pickle.dump(bolsa_palabras_hd, f)
        with open("bolsa_palabras_hd_a_o.pickle", "wb") as f:
            pickle.dump(bolsa_palabras_hd_a_o, f)


#cargar bolsa de palabras
    def obtener_variables(self):
        with open("bolsa_palabras_hd.pickle", "rb") as f:
            bolsa_palabras_hd=pickle.load(f)
        with open("bolsa_palabras_hd_a_o.pickle", "rb") as f:
            bolsa_palabras_hd_a_o=pickle.load(f)
        return bolsa_palabras_hd, bolsa_palabras_hd_a_o

    def Jaccard(self,documento1,documento2):
        c1=set(documento1)
        c2=set(documento2)
        resultado=((len(c1.intersection(c2)))/(len(c1.union(c2))))*100
        if(resultado==0):
            return 0
        else:
            return resultado

    def prob_evento(self,documento,documento1):
        d0=0
        d1=0
        for i in documento:
            if(i==1):
                d0+=1
        for i in documento1:
            if(i==1):
                d1+=1
        resultado=d1/d0
        return resultado*100

    def k_nn(self,documento,documento1):
        pass
#bolsa de palabras
    def procesamiento_texto(self,documento):
        derivar=stem.snowball.SnowballStemmer('spanish')
        dicc={"á":"a","é":"e","í":"i","ó":"o","ú":"u",".":"",",":"","-":"","(":"",")":"","{":"","}":"","?":"","¿":"",";":"",":":"",'"':"","!":"","¡":"","\r":"","\n":"","+":""}
        #stopwords=corpus.stopwords.words('spanish')
        lista_palabras_vacias=("el","la","lo","los","las","un","una","unos","unas","al","del","y","e","o","u","pero","sino","aunque","si","porque","como","para",
        "tanto","que","ni","no","solo","sino","tambien","asi","como","a","ante","bajo","cabe","con","contra","de","desde","durante","en","entre","hacia","hasta",
        "mediante","para","por","según","sin","sobre","tras","pro","via","etc","ya","dado","pues","tal")
        #pasar en minusculas el texto
        aux=list()
        vector=list()
        doc=documento.lower().split(" ")
        #print("Split: ",doc)
        #verificar si son palabras
        for x in doc:
            if(x.isalpha()):
                tabla=x.maketrans(dicc)
                aux.append(x.lower().translate(tabla))
            else:
                for y in x.split("/"):
                    tabla=y.maketrans(dicc)
                    aux.append(y.lower().translate(tabla))
        #print("Split sin diagonal: ",aux)
        #eliminar palabras vacias
        #print("Quitar palabras de diccionario: ",aux)
        for i in aux:
            if(i not in lista_palabras_vacias):
                if(len(i)>2):
                    vector.append(i)
        #print("Vector procesado: ",vector)
        bolsa_palabras=list(set(vector))
        #print("Bolsa de palabras: ",bolsa_palabras)
        bolsa_raiz_palabras=[derivar.stem(x) for x in bolsa_palabras]
        print("Bolsa de palabras raiz: ",bolsa_raiz_palabras)
        return bolsa_raiz_palabras

#cuear una string a partir de una lista
    def procesar(self,resultado):
        proceso=""
        for x in range(0,len(resultado)):
            proceso+=''.join(resultado[x])+" "
        return proceso

#crea el vector de la bolsa de palabras
    def vector_comparacion(self,bolsa):
        arreglo=list()
        for i in range(len(bolsa)):
            arreglo.append(int(1))
        return np.array(arreglo)

#crea el vector con el que se va a comparar la bolsa de palabras    
    def vector(self,bolsa,texto):
        arreglo=list()
        for i in bolsa:
            if(i in texto):
                arreglo.append(int(1))
            else:
                arreglo.append(int(0))
        return np.array(arreglo)
        
#·transformar datos
    def trans(self,datos):
        target=list()
        data=list()
        for i in datos:
            #print(i[0],i[1])
            target.append([i[0]])
            data.append(i[1])
        return data,target

#crear dataframe
    def d_frame(self,data,target,bolsa):
        aux1=list()
        for i in data:
            aux=list()
            for j in bolsa:
                if(j in i):
                    aux.append(int(1))
                else:
                    aux.append(int(0))
            aux1.append(aux)
        df=pd.DataFrame(aux1)
        return df

#crear expedientes y rutas(directorio)
    def crear_archivos(self,exp,ar):
        expediente=RUTA_DIR+str(exp)
        archivo=RUTA_DIR+str(exp)+"/"+str(ar)
        if (not os.path.exists(expediente)):
            os.mkdir(expediente)
            if (not os.path.exists(archivo)):
                os.mkdir(archivo)
        else:
            if (not os.path.exists(archivo)):
                os.mkdir(archivo)
        return archivo

#ruta de archivos: archivos/expediente/denuncia/archivo
    def crear_ruta_achivo(self,exp,folio,archivo):
        return RUTA_AR.format(exp,folio,archivo)

#guardar archivos
    def guardar_archivo(self,archivos,direccion):
        #pruebas_archivos
        for i in archivos:
            extension=i.filename.split(".")
            if(extension[1] in EXTENSIONES):
                a=secure_filename(i.filename)
                res=i.save(os.path.join(direccion,a))
        return 1

#crear graficas(indicadores)
    def indicadores(self,datos):
        etiquetas=list()
        expediente=datos[0][0]
        folio_den=datos[3]
        formato=[0.8]*len(datos[0])
        print("Tamaño: ",range(len(datos[0])))
        for i in range(len(datos[0])):
            if(datos[0][i] in diccionario_escuelas):
                etiquetas.append(diccionario_escuelas[datos[0][i]])
            else:
                etiquetas.append(datos[0][i])
        #print(etiquetas)
        #print("Expediente: ",expediente,"- Folio: ",folio_den)
        datos[0][0]="Denuciante"
        colores=['green']*len(datos[0])
        #uso de porcentajes para colores
        for i in range(len(datos[1])):
            division=(datos[1][i]/datos[2])*100
            print("Division: ",division)
            if(division<25):
                colores[i]='green'
            elif(division>=25 and division<75):
                colores[i]='yellow'
            else:
                colores[i]='crimson'
        print(colores)
        fig=go.Figure(go.Bar(
            x=datos[0],
            y=datos[1],
            hovertext=etiquetas,
            marker_color=colores
        ))
        fig.update_traces(
            marker_color=colores)
        fig.update_layout(
            title='Frecuencia de los agentes.',
            xaxis=dict(
                title='Valores de la denuncia.',
            ),
            yaxis=dict(
                title='Número de denuncias realizadas.',
            ))
        #pio.to_html(fig,RUTA_AR.format(str(expediente),str(folio_den),str(expediente)+"_"+str(folio_den)+".html"),auto_play=False,full_html=False)
        pio.write_html(fig,RUTA_DIR+str(expediente)+"/"+str(folio_den)+"/"+str(expediente)+"_"+str(folio_den)+".html",full_html=False)
        resultado=RUTA_AR.format(str(expediente),str(folio_den),str(expediente)+"_"+str(folio_den)+".html")
        #resultado=po.plot(fig,include_plotlyjs=False, output_type='div')
        return resultado
        
#graficas de reportes
    def graficas(self,datos):
        texto=list()
        general_e,turno_e,perfil_e,ua_e,f_den_e,f_hec_e,f_hec_e_m,f_hec_e_y=list(),list(),list(),list(),list(),list(),list(),list()
        general_d,turno_d,perfil_d,ua_d,f_den_d,f_hec_d=list(),list(),list(),list(),list(),list()
        def_etiquetas=["Hechos","Denunciante","Denunciado"]
        cont=0
        aux_cont=0
        #general
        for i in datos:
            if(len(i)==1 and cont<3):
                general_e.append(def_etiquetas[cont])
                general_d.append(i[0][0])
                cont+=1
        #ua
        print(datos[3])
        for j in datos[3]:
            for d in diccionario_escuelas.items():
                if(j[0] in d[1]):
                    ua_e.append(d[0])
                    ua_d.append(j[1])
                    texto.append(j[0])    
        print("KEY: ",ua_e)
        print("Valor: ",ua_d)
        print("Etiqueta: ",texto)
        #perfil
        for i in datos[4]:
            if("Seleccionar" in i[0]):
                perfil_e.append("NA")
                perfil_d.append(i[1])
            else:
                perfil_e.append(i[0])
                perfil_d.append(i[1])
        #turno
        for i in datos[5]:
            if("Seleccionar" not in i[0]):
                turno_e.append(i[0])
                turno_d.append(i[1])
            else:
                turno_e.append("NA")
                turno_d.append(i[1])
        #fecha denuncia
        for i in datos[6]:
            f_den_e.append(i[0])
            f_den_d.append(i[1])
        #fecha de los hechos
        for i in datos[7]:
            f_hec_e.append(i[0].strftime("%Y-%m-%d"))
            f_hec_d.append(i[1])
            f_hec_e_m.append(int(i[0].strftime("%Y-%m-%d").split("-")[1]))
            f_hec_e_y.append(i[0].strftime("%Y-%m-%d").split("-")[0])
        
        fecha1=go.Scatter(x=f_den_e,y=f_den_d,name="Fecha denuncia")
        fecha2=go.Scatter(x=f_hec_e,y=f_hec_d,name="Fecha hechos")
        data=[fecha1,fecha2]
        fig_fecha=go.Figure(data=data)
        fig_fecha.update_layout(title="Fechas de eventos vs Fechas denuncias.",
                   xaxis_title="Fechas",
                   yaxis_title="Total de eventos")

        fig=make_subplots(
            rows=2,cols=3,
            specs=[[{"type":"bar"},{"type":"bar"},{"type":"bar"}],
            [{"type":"bar"},{"type":"bar"},{"type":"bar"}]],
            subplot_titles=("Mes del evento","Año del evento","Denunciados","Unidades académicas","Perfiles","Turnos"),
            print_grid=True,
            x_title="Variables",
            y_title="Total de eventos"
        )
        fig.add_trace(go.Bar(x=f_hec_e_m,y=f_hec_d,name="Mes del evento",),row=1,col=1)
        fig.add_trace(go.Scatter(x=f_hec_e_y,y=f_den_d,name="Año del evento"),row=1,col=2)
        fig.add_trace(go.Bar(x=general_e,y=general_d,name="Denunciados",width=[0.8]),row=1,col=3)
        fig.add_trace(go.Bar(x=ua_e,y=ua_d,hovertext=texto,name="Unidades académicas"),row=2,col=1)
        fig.add_trace(go.Bar(x=perfil_e,y=perfil_d,name="Perfil"),row=2,col=2)
        fig.add_trace(go.Bar(x=turno_e,y=turno_d,name="Turno"),row=2,col=3)
        fig.update_layout(title_text='Indicadores')
        pio.write_html(fig,RUTA_GRAFICAS.format("graficas.html"),full_html=False)
        resultado=RUTA_GRAFICAS_RELATIVO.format("graficas.html")
        pio.write_html(fig_fecha,RUTA_GRAFICAS.format("fechas.html"),full_html=False)
        resultado1=RUTA_GRAFICAS_RELATIVO.format("fechas.html")
        return resultado,resultado1

#cifrar clave
    def cifrar(self,clave):
        cifrar=hashlib.sha256(clave.encode("utf-8"))
        c_cifrado=cifrar.hexdigest()
        print(c_cifrado,len(c_cifrado))
        return c_cifrado

#exportar base de datos en formato csv
    def exportar_base(self,nombre):
        mensaje=""
        cadena=("mysql -u root --password='{}'  -e 'select * from BD_TT1.Datos_{}' -B > '{}'.csv").format(CONTRASENA,nombre.get("optradio"),RUTA_DIR+nombre.get("nombre_base"))
        print("Query: ",cadena)
        error=os.system(cadena)
        if(os.path.isfile(RUTA_DIR+nombre.get("nombre_base")+".csv")):
            mensaje="Correcto, Base de datos descargada."
        else:
            mensaje="Base de datos no descargada."
        return mensaje

#formar query
    def f_query(self,datos):
        denunciante={
            "nombre":"Nombre",
            "primer_apellido":"P_apellido",
            "segundo_apellido":"S_apellido"
        }
        buscar={
            "denunciante":denunciante,
            "denunciado":"Nombre_d",
            "ua":"UA_DEP_d",
            "perfil":"Perfil_d",
            "turno":"Turno_d",
            "f_evento":"F_hechos",
            "f_denuncia":"F_denuncia"
        }
        r1=buscar[datos.get("busqueda")]
        r2=buscar[datos.get("comparar")]
        valor=datos.get("nombre_base")
        return (r2,r1,valor)

#frafica de la busqueda
    def graf_res(self,datos):
        x,y,etiquetas=list(),list(),list()
        print("Tamaño: ",datos)
        for i in datos:
            if(i[0] in diccionario_escuelas):
                etiquetas.append(diccionario_escuelas[i[0]])
            else:
                etiquetas.append(i[0])
            x.append(i[0])
            y.append(i[1])
        fig=go.Figure(go.Bar(
            x=x,
            y=y,
            hovertext=etiquetas
        ))
        fig.update_layout(
            title='Frecuencia',
            xaxis=dict(
                title='Valores de busqueda.',
            ),
            yaxis=dict(
                title='Total de apariciones.',
            ))
        #pio.to_html(fig,RUTA_AR.format(str(expediente),str(folio_den),str(expediente)+"_"+str(folio_den)+".html"),auto_play=False,full_html=False)
        pio.write_html(fig,RUTA_GRAFICAS.format("busqueda_graficas.html"),full_html=False)
        resultado=RUTA_GRAFICAS_RELATIVO.format("busqueda_graficas.html")
        #resultado=po.plot(fig,include_plotlyjs=False, output_type='div')
        return resultado

#diccionario
    def diccionario(self,etiqueta):
        resultado=""
        if (etiqueta in diccionario_escuelas):
            resultado=diccionario_escuelas[etiqueta]
        return resultado

#clasificacion de los algoritmos
#datos[0]=codigo de accion, 0-entrenar y 1-predecir.
#datos[1]=datos.
#datos[2]=etiquetas a entrenar(las etiquetas de entrenamiento son los id de la base de datos).

#naivebayes bernoulli
    def bernoulli_bayesingenuo(self,*datos):
        respuesta=0
        dimension=datos[1].shape
        if(datos[0]==0):
            b_nb=BernoulliNB()
            ent_bnb=b_nb.fit(datos[1],datos[2])
            joblib.dump(ent_bnb, 'naive_bayes_bernoulli.pkl')
        if(datos[0]==1):
            dat_p=datos[1].reshape((1,-1))
            predecir=joblib.load('naive_bayes_bernoulli.pkl')
            respuesta=predecir.predict(dat_p)
        return respuesta

#red neuronal shallow
    def shallow_nn(self,*datos):
        respuesta=0
        dimension=datos[1].shape
        if(datos[0]==0):
            shallow=BernoulliNB()
            ent_shallow=shallow.fit(datos[1],datos[2])
            joblib.dump(ent_shallow, 'shallow_network.pkl')
        if(datos[0]==1):
            dat_p=datos[1].reshape((1,dimension[0]))
            predecir=joblib.load('naive_bayes_bernoulli.pkl')
            respuesta=predecir.predict(dat_p)
        return respuesta
    
#vecinos cercanos aprendizaje no supervisado
    def nn(self,*datos):
        respuesta=0
        dimension=datos[1].shape
        if(datos[0]==0):
            nn=NearestNeighbors(n_neighbors=len(datos[2]))
            ent_nn=nn.fit(datos[1],datos[2])
            joblib.dump(ent_nn, 'nn.pkl')
        if(datos[0]==1):
            dat_p=datos[1].reshape((1,dimension[0]))
            predecir=joblib.load('nn.pkl')
            respuesta=predecir.predict(dat_p)
        return respuesta

#clasificacion de vecinos cercanos
    def vecinoscercanos(self,*datos):
        respuesta=0
        dimension=datos[1].shape
        if(datos[0]==0):
            knn=KNeighborsClassifier(n_neighbors=len(datos[2]))
            ent_knn=knn.fit(datos[1],datos[2])
            joblib.dump(ent_knn, 'knn.pkl')
        if(datos[0]==1):
            dat_p=datos[1].reshape((1,dimension[0]))
            predecir=joblib.load('knn.pkl')
            respuesta=predecir.predict(dat_p)
        return respuesta

#regresion logistica multiclase