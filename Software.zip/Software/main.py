import numpy as np
from flask import Flask, render_template, request, redirect, url_for, session
from formulario import FormBuilder
from base_datos import Mysql_Builder
from logica_negocio import Buissnes_Builder, RUTA_GRAFICAS
from flask_mail import Mail, Message

app=Flask(__name__)
app.config['SECRET_KEY'] = '7110c8ae51a4b5af97be6534caef90e4bb9bdcb3380af008f90b23a5d16'
mail=Mail(app)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT']=465
app.config['MAIL_USE_SSL']=True
app.config['MAIL_USERNAME']='emergos12@gmail.com'
app.config['MAIL_PASSWORD']='emergos90@'
mail=Mail(app)

@app.route('/')
def index():
    return redirect('principal.html')

"""
@app.route('/agenda.html', methods=["GET", "POST"])
def agenda():
    formulario=FormBuilder()
    return render_template('/agenda.html',form=formulario)

@app.route('/agenda_nueva', methods=["GET", "POST"])
def agenda_nueva():
    formulario=FormBuilder()
    if(request.method=='POST'):
        print(request.values)
    return render_template('/agenda.html',form=formulario)

@app.route('/tareas.html', methods=["GET", "POST"])
def tarea():
    formulario=FormBuilder()
    if(request.method=='POST'):
        print(len(request.values))
    return render_template('/tareas.html',form=formulario)

@app.route('/tarea_nueva', methods=["GET", "POST"])
def tarea_nueva():
    formulario=FormBuilder()
    if(request.method=='POST'):
        print(len(request.values))
    return render_template('/tareas.html',form=formulario)
"""

@app.route('/principal.html')
def principal():
    return render_template('/principal.html')

@app.route('/login.html', methods=["GET", "POST"])
def login():
    mensaje="2"
    pantalla="login.html"
    if(request.method=="POST"):
        base=Mysql_Builder()
        clave=request.form.get("contrasena")
        lg=Buissnes_Builder()
        conexion=base.conexion()
        resultado=base.login(conexion,request.form,contrasena=lg.cifrar(clave))
        base.desconectar(conexion)
        #print(resultado[1])
        if(resultado is not None):
            if('Trabajador' in resultado):
                session['perfil'],session['id']=resultado[0],resultado[1]
                return redirect('/denuncia.html')
            elif('Administrador de usuarios' in resultado):
                session['perfil']=resultado[0]
                return redirect('/usuario.html')
            elif('Administrador de herramientas' in resultado):
                session['perfil'],session['id']=resultado[0],resultado[1]
                return redirect('/herramientas.html')
        else:
            mensaje="Correo electrónico/Contraseña incorrecto"
    return render_template('/login.html',mensaje=mensaje,pantalla=pantalla)

@app.route('/usuario.html', methods=["GET", "POST"])
def usuario():
    if('perfil' not in session):
        return redirect('/login.html')
    elif('Administrador de usuarios' not in session['perfil']):
        return redirect('/login.html')
    else:
        pantalla="usuario.html"
        perfil=session['perfil']
        print("perfil",perfil)
        usuario="usuario"
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.seleccionar(conexion,usuario)
        base.desconectar(conexion)
        if(request.method=='POST'):
            base=Mysql_Builder()
            conexion=base.conexion()
            print(len(request.form))
            #print(request.form)
            lg=Buissnes_Builder()
            if(len(request.form)==7 and request.form.get("contraseña")):
                clave=request.form.get("contrasena")
                mensaje=base.agregar(conexion,usuario,request.form,contrasena=lg.cifrar(clave))
                print(mensaje)
                aux,resultado=base.seleccionar(conexion,usuario)
            if(request.form.get("id")):
                clave=request.form.get("contrasena")
                mensaje=base.actualizar(conexion,usuario,request.form)
                aux,resultado=base.seleccionar(conexion,usuario)
            if(len(request.form)==1):
                mensaje=base.eliminar(conexion,usuario,request.form.get("eliminar"))
                aux,resultado=base.seleccionar(conexion,usuario)
            base.desconectar(conexion)
    return render_template('/usuario.html',perfil=perfil,datos=resultado,mensaje=mensaje,pantalla=pantalla)

@app.route('/e_correo', methods=["GET", "POST"])
def e_correo():
    print(request.form.get("e_cor"))
    mensaje=Message('Cambio de contraseña',sender=app.config['MAIL_USERNAME'],recipients=[request.form.get("e_cor")])
    mensaje.html= '<p>Se solicitó recientemente cambiar la contraseña de su cuenta.<br>Acceda al link para cambiar la contraseña.<br>http://127.0.0.1:60000/contrasena.html/{}<br></p>'.format(request.form.get("e_id"))
    mail.send(mensaje)
    return redirect('usuario.html')

@app.route('/contrasena.html/<id>', methods=["GET", "POST"])
def contrasena(id):
    mensaje="2"
    contrasena="contraseña"
    print(id)
    if(request.method=="POST"):
        lg=Buissnes_Builder()
        clave=request.form.get("contrasena1")
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje=base.actualizar(conexion,contrasena,id,contrasena1=lg.cifrar(clave))
        base.desconectar(conexion)
    return render_template('/contrasena.html',id=id,mensaje=mensaje)

@app.route('/herramientas.html', methods=["GET", "POST"])
def herrmientas():
    global bolsa_palabras_hd_a_o
    global bolsa_palabras_hd
    if('perfil' not in session):
        print("her_noperfil")
        return redirect('/login.html')
    elif('Administrador de herramientas' not in session['perfil']):
        print('her_no_permiso_admin')
        return redirect('/login.html')
    else:
        herramienta="herramienta"
        pantalla="herramientas.html"
        perfil=session['perfil']
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.seleccionar(conexion,herramienta)
        base.desconectar(conexion)
        if(request.method=='POST'):
            #print(len(request.form))
            base=Mysql_Builder()
            conexion=base.conexion()
            if(len(request.form)==5):
                mensaje=base.agregar(conexion,herramienta,request.form)
                #
            if(request.form.get("id")):
                mensaje=base.actualizar(conexion,herramienta,request.form)
                #
            if(len(request.form)==1):
                mensaje=base.eliminar(conexion,herramienta,request.form.get("eliminar"))
            aux,resultado=base.seleccionar(conexion,herramienta)
            if("Correcto" in mensaje):
                global bolsa_palabras_hd_a_o
                global bolsa_palabras_hd
                lg=Buissnes_Builder()
                print("Procesamiento para Jaccard")
                query=base.seleccionar(conexion,"cuestionario")
                print("Query: ",type(query))
                texto_procesado=lg.procesar(query)
                bolsa_palabras_hd=lg.procesamiento_texto(texto_procesado)
                print("Procesamiento y clasificacion")
                query1=base.seleccionar(conexion,"clasificacion")
                data,target=lg.trans(query1)
                data_aux=lg.procesar(data)
                bolsa_palabras_hd_a_o=lg.procesamiento_texto(data_aux)
                df=lg.d_frame(data,target,bolsa_palabras_hd_a_o)
                print(df)
                lg.inicializar_variables(bolsa_palabras_hd,bolsa_palabras_hd_a_o)
                lg.bernoulli_bayesingenuo(0,df,target)
                lg.vecinoscercanos(0,df,target)
                base.desconectar(conexion)
    return render_template('/herramientas.html',perfil=perfil,datos=resultado,mensaje=mensaje,pantalla=pantalla)

@app.route('/denuncia.html', methods=["GET", "POST"])
def denuncia():
    if('perfil' not in session):
        print("her_noperfil")
        return redirect('/login.html')
    elif(('Administrador de herramientas' in session['perfil']) or ('Trabajador' in session['perfil'])):
        denuncia="denuncia"
        pantalla="denuncia.html"
        perfil=session['perfil']
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.seleccionar(conexion,denuncia)
        print("Resultado: ",resultado)
        base.desconectar(conexion)
    return render_template('/denuncia.html',perfil=perfil,datos=resultado,mensaje=mensaje,pantalla=pantalla)

@app.route('/denuncia_usr.html/<int:folio>', methods=["GET", "POST"])
def denuncia_usr(folio):
    if('perfil' not in session):
        print("her_noperfil")
        return redirect('/login.html')
    else:
        denuncia_usr="d_usr"
        estadisticas="estadisitcas"
        pantalla="denuncia_usr.html"
        perfil=session['perfil']
        id=session['id']
        lg=Buissnes_Builder()
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.seleccionar(conexion,denuncia_usr,id=folio)
        mensaje_est,resultado_est=base.seleccionar(conexion,estadisticas,id=folio)
        grafica=lg.indicadores(resultado_est)
        base.desconectar(conexion)
        print("Resultado: ",mensaje_est,type(mensaje))
        #cuestionario de analisis
        if(request.method=='POST'):
            #print(len(request.form))
            analisis="analisis"
            base=Mysql_Builder()
            conexion=base.conexion()
            mensaje=base.actualizar(conexion,analisis,request.form,id=folio,id_usr=id)
            print("Mensaje: ",mensaje)
            base.desconectar(conexion)
            #,datos1=resultado_est
    return render_template('/denuncia_usr.html',perfil=perfil,datos=resultado,grafica=grafica,folio=folio,mensaje=mensaje,pantalla=pantalla)

@app.route('/reportes.html', methods=["GET", "POST"])
def reportes():
    mensaje="2"
    if('perfil' not in session):
        print("her_noperfil")
        return redirect('/login.html')
    elif(('Administrador de herramientas' in session['perfil']) or ('Trabajador' in session['perfil'])):
        if(('Administrador de herramientas' in session['perfil'])):
            bandera=1
        else:
            bandera=0
        reporte="indicadores"
        pantalla="reportes.html"
        info="informacion"
        busqueda="busqueda_informacion"
        perfil=session['perfil']
        graficas=""
        i_personalizada=""
        graf_personalizado=""
        base=Mysql_Builder()
        lg=Buissnes_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.seleccionar(conexion,reporte)
        busqueda=base.seleccionar(conexion,info)
        base.desconectar(conexion)
        indicadores,fechas=lg.graficas(resultado)
        if(request.method=='POST' and len(request.form)==2):
            mensaje=lg.exportar_base(request.form)
        elif(request.method=='POST'):
            base=Mysql_Builder()
            conexion=base.conexion()
            res=lg.f_query(request.form)
            print("Longuitud: ",len(request.form))
            i_personalizada=base.seleccionar_info(conexion,res)
            graf_personalizado=lg.graf_res(i_personalizada)
            base.desconectar(conexion)
    return render_template('/reportes.html',perfil=perfil,pantalla=pantalla,datos=indicadores,datos_fechas=fechas,explorar=busqueda,info_per=graf_personalizado,mensaje=mensaje,grafica=graficas,bandera=bandera)

@app.route('/logout')
def logout():
    if('perfil' in session):
        session.pop('perfil',None)
    if('id' in session):
        session.pop('id',None)
    return redirect('/principal.html')

@app.route('/login_usr.html', methods=["GET", "POST"])
def login_usr():
    mensaje="2"
    pantalla="login_usr.html"
    if(request.method=="POST"):
        base=Mysql_Builder()
        clave=request.form.get("contrasena")
        lg=Buissnes_Builder()
        conexion=base.conexion()
        resultado=base.login_usr(conexion,request.form,contrasena=lg.cifrar(clave))
        base.desconectar(conexion)
        #print(resultado[1])
        if(resultado is not None):
            session['id'],session['edad']=resultado[0],resultado[1]
            return redirect('/historial_usr.html')
        else:
            mensaje="Correo electrónico/Contraseña incorrecto"
    return render_template('/login_usr.html',mensaje=mensaje,pantalla=pantalla)

@app.route('/registro_usr.html', methods=["GET", "POST"])
def registro_usr():
    mensaje="2"
    pantalla="registro_usr.html"
    usuario="usuario"
    if(request.method=='POST'):
        base=Mysql_Builder()
        conexion=base.conexion()
        #print(request.form)
        lg=Buissnes_Builder()
        clave=request.form.get("contrasena")
        mensaje=base.registro_usr(conexion,usuario,request.form,contrasena=lg.cifrar(clave))
        print(mensaje)
        base.desconectar(conexion)
    return render_template('/registro_usr.html',mensaje=mensaje,pantalla=pantalla)

@app.route('/cuestionario_usr.html', methods=["GET", "POST"])
def cuestionario_usr():
    if('id' not in session):
        print("his_noperfil")
        return redirect('/login_usr.html')
    else:
        historial_usr="cuestionario_usr"
        pantalla="cuestionario_usr.html"
        perfil=session['id']
        print("Perfil: ",perfil)
        mensaje="2"
        if(request.method=='POST'):
            lg=Buissnes_Builder()
            #clasificar Jaccard
            bolsa_palabras_hd,bolsa_palabras_hd_a_o=lg.obtener_variables()
            bolsa_palabras_descripcion=lg.procesamiento_texto(request.form.get("hechos_descripcion"))
            vector=lg.vector(bolsa_palabras_hd,bolsa_palabras_descripcion)
            print("Jaccard: ",lg.Jaccard(bolsa_palabras_descripcion,bolsa_palabras_hd))
            #clasificar denuncia
            vector=lg.vector(bolsa_palabras_hd_a_o,bolsa_palabras_descripcion)
            valor_p0=lg.bernoulli_bayesingenuo(1,vector)
            valor_p1=lg.vecinoscercanos(1,vector)
            print(valor_p0[0],valor_p1[0])
            base=Mysql_Builder()
            conexion=base.conexion()
            mensaje=base.cuestionario_usr(conexion,request.form,archivos=request.files,id=perfil,jaccard=0.5,nb=valor_p0[0],shallow=.035,nn=valor_p1[0])
            print("Mensaje: ",mensaje)
            base.desconectar(conexion)
    return render_template('/cuestionario_usr.html',perfil=perfil,mensaje=mensaje,pantalla=pantalla)

@app.route('/historial_usr.html', methods=["GET", "POST"])
def historial_usr():
    if('id' not in session):
        print("his_noperfil")
        return redirect('/login_usr.html')
    else:
        historial_usr="historial_usr"
        pantalla="historial_usr.html"
        perfil=session['id']
        print("Perfil: ",perfil)
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.historial_usr(conexion,id=perfil)
        print(resultado)
        print(mensaje)
        base.desconectar(conexion)
    return render_template('/historial_usr.html',perfil=perfil,datos=resultado,mensaje=mensaje,pantalla=pantalla)

@app.route('/historial_usr_den.html/<int:folio>',methods=["GET","POST"])
def historial_usr_den(folio):
    if('id' not in session):
        print("his_noperfil")
        return redirect('/login_usr.html')
    else:
        historial_usr="historial_usr_den"
        pantalla="historial_usr_den.html"
        perfil=session['id']
        print("Perfil: ",perfil)
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.historial_usr_den(conexion,id=perfil)
        base.desconectar(conexion)
    return render_template('/historial_usr_den.html',perfil=perfil,datos=resultado,mensaje=mensaje,pantalla=pantalla)

@app.route('/datos_usr.html', methods=["GET", "POST"])
def datos_usr():
    if('id' not in session):
        print("his_noperfil")
        return redirect('/login_usr.html')
    else:
        usuario_usr="usuario_usr"
        actualizacion_usr="actualizar_usr"
        pantalla="datos_usr.html"
        perfil=session['id']
        print("Perfil: ",perfil)
        base=Mysql_Builder()
        conexion=base.conexion()
        mensaje,resultado=base.datos_usr(conexion,usuario_usr,id=perfil)
        print("mensaje: ",mensaje,"resultado: ",resultado)
        base.desconectar(conexion)
        if(request.method=='POST'):
            base=Mysql_Builder()
            conexion=base.conexion()
            #print(request.form)
            mensaje=base.actualizar_usr(conexion,actualizacion_usr,request.form,id=perfil)
            print("Actualizar: ",mensaje)
            base.desconectar(conexion)
    return render_template('/datos_usr.html',perfil=perfil,datos=resultado,mensaje=mensaje,pantalla=pantalla)

@app.route('/aviso.html', methods=["GET", "POST"])
def aviso():
    return render_template('/aviso.html')

if(__name__=='__main__'):
    app.run(debug=True,port=60000)