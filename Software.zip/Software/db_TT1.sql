CREATE DATABASE IF NOT EXISTS BD_TT1;
USE BD_TT1;
/*Denuncia*/
CREATE TABLE IF NOT EXISTS `Datos_denunciante` (
    `ID_denunciante` INT UNSIGNED AUTO_INCREMENT,
    `Nombre` varchar(50),
    `P_apellido` varchar(50),
    `S_apellido` varchar(50),
    `F_nacimiento` DATE,
    `Edad` TINYINT UNSIGNED,
    `Genero` varchar(20),
    `Otro_genero` varchar(50),
    `C_electronico` varchar(254),
    `T_celular` varchar(10),
    `T_fijo_ext` varchar(26),
    `Domicilio` TEXT,
    PRIMARY KEY (`ID_denunciante`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_tutor`(/*agregar id de la denuncia*/
    `ID_tutor` INT UNSIGNED AUTO_INCREMENT,
    `ID_denunciante` INT UNSIGNED,
    `Nombre_completo` varchar(200),
    `Edad_t` TINYINT UNSIGNED,
    `Genero_t` varchar(20),
    `Otro_genero_t` varchar(50),
    `T_celular_t` varchar(10),
    `T_fijo_ext_t` varchar(26),
    `Domicilio_t` TEXT,
    `C_electronico_t` varchar(254),
    PRIMARY KEY (`ID_tutor`),
    FOREIGN KEY (`ID_denunciante`) REFERENCES `Datos_denunciante`(`ID_denunciante`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
/*
F_denuncia varchar(11)
F_hechos DATE
*/
CREATE TABLE IF NOT EXISTS `Datos_hechos`(
    `ID_hechos` INT UNSIGNED AUTO_INCREMENT,
    `ID_denunciante` INT UNSIGNED,
    `Anonimo` varchar(5),
    `F_denuncia` varchar(11),
    `H_denuncia` varchar(9),
    `F_hechos` DATE,
    `H_hechos` TIME,
    `Lugar` TEXT,
    `Descripcion_hechos` TEXT,
    PRIMARY KEY (`ID_hechos`),
    FOREIGN KEY (`ID_denunciante`) REFERENCES `Datos_denunciante`(`ID_denunciante`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_academicos` (
    `ID_academico` INT UNSIGNED AUTO_INCREMENT,
    `ID_denunciante` INT UNSIGNED,
    `ID_hechos` INT UNSIGNED,
    `UA_DEP` varchar(256),
    `Turno` varchar(15),
    `Perfil` varchar(20),
    `Numero_boleta` varchar(10),
    `Semestre` varchar(5),
    `Grupo` varchar(10),
    `Carrera` varchar(256),
    `Numero_empleado` varchar(20),
    `Nombre_superior` varchar(150),
    `Descripcion` varchar(100),
    PRIMARY KEY (`ID_academico`),
    FOREIGN KEY (`ID_denunciante`) REFERENCES `Datos_denunciante`(`ID_denunciante`),
    FOREIGN KEY (`ID_hechos`) REFERENCES `Datos_hechos`(`ID_hechos`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_denunciado`(
    `ID_denunciado` INT UNSIGNED AUTO_INCREMENT,
    `ID_denunciante` INT UNSIGNED,
    `ID_hechos` INT UNSIGNED,
    `Nombre_d` varchar(150),
    `UA_DEP_d` varchar(256),
    `Turno_d` varchar(15),
    `Perfil_d` varchar(20),
    `Semestre_d` varchar(5),
    `Grupo_d` varchar(10),
    `Carrera_d` varchar(256),
    `Puesto_d` varchar(100),
    `Nombre_superior_d` varchar(150),
    PRIMARY KEY (`ID_denunciado`),
    FOREIGN KEY (`ID_denunciante`) REFERENCES `Datos_denunciante`(`ID_denunciante`),
    FOREIGN KEY (`ID_hechos`) REFERENCES `Datos_hechos`(`ID_hechos`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_testigo`(
    `ID_testigo` INT UNSIGNED AUTO_INCREMENT,
    `ID_denunciante` INT UNSIGNED,
    `ID_hechos` INT UNSIGNED,
    `Nombre_te` varchar(150),
    `C_electronico_te` varchar(254),
    `T_celular_te` varchar(10),
    `T_fijo_ext_te` varchar(26),
    PRIMARY KEY (`ID_testigo`),
    FOREIGN KEY (`ID_denunciante`) REFERENCES `Datos_denunciante`(`ID_denunciante`),
    FOREIGN KEY (`ID_hechos`) REFERENCES `Datos_hechos`(`ID_hechos`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_pruebas`(
    `ID_pruebas` INT UNSIGNED AUTO_INCREMENT,
    `ID_denunciante` INT UNSIGNED,
    `ID_hechos` INT UNSIGNED,
    `Denuncia` varchar(4),
    `Lista_evidencias` TEXT,
    `Archivos` TEXT,
    `Direccion_elec` varchar(256),
    PRIMARY KEY (`ID_pruebas`),
    FOREIGN KEY (`ID_denunciante`) REFERENCES `Datos_denunciante`(`ID_denunciante`),
    FOREIGN KEY (`ID_hechos`) REFERENCES `Datos_hechos`(`ID_hechos`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_herramientas` (
    `ID_herramientas` INT UNSIGNED AUTO_INCREMENT,
    `Herramienta` varchar(256),
    `Categoria` varchar(100),
    `Regla` varchar(256),
    `Numero` varchar(4),
    `Color` varchar(7),
    PRIMARY KEY (`ID_herramientas`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_clasificacion`(
    `ID_clasificacion` INT UNSIGNED AUTO_INCREMENT,
    `ID_hechos` INT UNSIGNED,
    `ID_herramientas`INT UNSIGNED,
    `Validacion` FLOAT,
    `Jaccard` FLOAT,
    `Naive_bayes` FLOAT,
    `Shallow` FLOAT,
    `S_NN`FLOAT,
    PRIMARY KEY (`ID_clasificacion`),
    FOREIGN KEY (`ID_hechos`) REFERENCES `Datos_hechos`(`ID_hechos`),
    FOREIGN KEY (`ID_herramientas`) REFERENCES `Datos_herramientas`(`ID_herramientas`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_empleado` (
    `ID_empleado` INT UNSIGNED AUTO_INCREMENT,
    `Nombre` varchar(50),
    `P_apellido` varchar(50),
    `S_apellido` varchar(50),
    `Empleado` INT UNSIGNED,
    `Perfil` varchar(30),
    `C_electronico` varchar(254),
    PRIMARY KEY (`ID_empleado`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_usuario` (
    `ID_usuario` INT UNSIGNED AUTO_INCREMENT,
    `Cuenta` INT UNSIGNED,
    `Contrasena` varchar(127),
    PRIMARY KEY (`ID_usuario`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `Datos_analisis` (
    `ID_analisis` INT UNSIGNED AUTO_INCREMENT,
    `ID_hechos` INT UNSIGNED,
    `ID_usuario` INT UNSIGNED,
    `ID_clasificacion` INT UNSIGNED,
    `Estado` varchar(20),
    `Confirmacion` varchar(5),
    `Comentarios` TEXT,
    PRIMARY KEY (`ID_analisis`),
    FOREIGN KEY (`ID_hechos`) REFERENCES `Datos_hechos`(`ID_hechos`),
    FOREIGN KEY (`ID_usuario`) REFERENCES `Datos_usuario`(`ID_usuario`),
    FOREIGN KEY (`ID_clasificacion`) REFERENCES `Datos_clasificacion`(`ID_clasificacion`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

INSERT INTO `Datos_empleado` (`Nombre`,`P_apellido`,`S_apellido`,`Empleado`,`Perfil`,`C_electronico`) VALUES ('Èmmanuel','Rosado','Martínez',2012630399,'Administrador de usuarios','emergos12@gmail.com');
INSERT INTO `Datos_empleado` (`Nombre`,`P_apellido`,`S_apellido`,`Empleado`,`Perfil`,`C_electronico`) VALUES ('Èmmanuel','Rosado','Martínez',2012630399,'Administrador de herramientas','emergos12@gmail.com');
INSERT INTO `Datos_empleado` (`Nombre`,`P_apellido`,`S_apellido`,`Empleado`,`Perfil`,`C_electronico`) VALUES ('Èmmanuel','Rosado','Martínez',2012630399,'Trabajador','emergos12@gmail.com');

INSERT INTO `Datos_usuario`(`Cuenta`,`Contrasena`) VALUES (1,'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f');
INSERT INTO `Datos_usuario`(`Cuenta`,`Contrasena`) VALUES (2,'e24df920078c3dd4e7e8d2442f00e5c9ab2a231bb3918d65cc50906e49ecaef4');
INSERT INTO `Datos_usuario`(`Cuenta`,`Contrasena`) VALUES (3,'69f625a2b0a661a7c2ce747049d465c6fb8e81f8dcd79c71439c82208b3ac723');

INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (1,'Onceálogo','Víctima','He recibido piropos o comentarios soeces sobre mi apariencia','1','#d02d76');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (2,'Onceálogo','Víctima','Me han mirado de tal manera que me he sentido incomodo/a','2','#be3f85');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (3,'Onceálogo','Víctima','Me han pedido favores de tipo sexual a cambio de asignarme una calificación/promoción','3','#ae4a8e');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (4,'Onceálogo','Víctima','Me he sentido incomodo/a con la manera que me saludan/abrazan','4','#994f97');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (5,'Onceálogo','Víctima','He recibido amenazas para realizar favores de tipo sexual de otras personas','5','#85519b');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (6,'Onceálogo','Víctima','He sido citada/o invitada/o fuera del espacio escolar/laboral para resolver asuntos ajenos al trabajo/escuela','6','#73549f');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (7,'Onceálogo','Víctima','Me han tomado fotografías sin mi consentimiento','7','#5f5398');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (8,'Onceálogo','Víctima','He recibido fotografías intimas sin haberlas solicitado','8','#5c519e');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (9,'Onceálogo','Victima','Me han espiado/acechado de manera fisica o virtual','9','#55519c');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (10,'Onceálogo','Victima','Se han aprovechado de mi posición de subordinación para toquetearme','10','#56529b');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (11,'Onceálogo','Víctima','Me han pedido formar grupos de Whatsapp o en Facebook, para posteriormente de forma privada enviar mensajes, invitaciones o fotos íntimas ','11','#52519c');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (12,'Acosómetro','NA','Dirigir miradas morbosas y gestos obscenos','1','#211b46');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (13,'Acosometro','NA','Realizar piropos o comentarios soeces','2','#241e4a');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (14,'Acosometro','NA','Realizar bromar o rumores de caracter sexual sobre la apariencia fisica de las personas','3','#2c2251');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (15,'Acosometro','NA','Realizar bromas, difundir rumores, ridiculizar a una persona por su orientación sexual, identidad o expresion de genero','4','#392961');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (16,'Acosometro','NA','Condicionar el uso de falda, vestido o ropa ajustada','5','#443070');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (17,'Acosometro','NA','Citar fuera del espacio y horario escolar','6','#4d3070');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (18,'Acosometro','NA','Coaccionar para mantener una relación sentimental','7','#582f71');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (19,'Acosometro','NA','Realizar comentarios y señas de tipo sexual','8','#5e2f71');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (20,'Acosometro','NA','Seguir, espiar, stalkear','9','#622f71');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (21,'Acosometro','NA','Tomar y compartir fotografias/videos sin consentimiento','10','#682e71');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (22,'Acosometro','NA','Establecer contacto sin finalidad academica o laboral por cualquier por cualquier medio de comunicación','11','#6b2f72');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (23,'Acosometro','NA','Enviar o solicitar videos/fotografias sexuales','12','#773077');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (24,'Acosometro','NA','Presionar para obtener favores sexuales','13','#87327d');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (25,'Acosometro','NA','Represalias por no obtener favores sexuales','14','#933682');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (26,'Acosometro','NA','Exhibicionismo','15','#9a3985');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (27,'Acosometro','NA','Roces con los genitales','16','#a23a89');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (28,'Acosometro','NA','Besos, tocamientos o cualquier contacto fisico sin consentimiento','17','#aa3e8d');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (29,'Reglas de integridad','NA','Uso y exhibición de materiales de carácter sexual fuera del ámbito académico','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (30,'Reglas de integridad','NA','Comentarios, chistes o bromas de contenido sexual que resultan desagradables y ofensivos','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (31,'Reglas de integridad','NA','Comentarios ofensivos o discriminatorios sobre la apariencia de la persona','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (32,'Reglas de integridad','NA','Contactos físicos, acercamientos, tocamientos o caricias innecesarias, con carácter deliberado, no deseados o que incomoden','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (33,'Reglas de integridad','NA','Insinuar o provocar intencionadamente situaciones para quedarse a solas con la persona acosada','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (34,'Reglas de integridad','NA','Observar clandestinamente a personas en lugares reservados, como sanitarios, vestidores, etc','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (35,'Reglas de integridad','NA','Invitaciones comprometedoras, insistencia en que la persona participe en conversaciones o bromas de contenido sexual','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (36,'Reglas de integridad','NA','Dejar notas o enviar correo electrónico, mensajes y cartas de carácter sexual que resulten ofensivos e intimidatorios','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (37,'Reglas de integridad','NA','Insinuar o proponer mejoras laborales o académicas a cambio de intercambios sexuales','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (38,'Reglas de integgridad','NA','Ignorar las aportaciones de las mujeres del grupo, menospreciar su trabajo, conocimientos o habilidades','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (39,'Reglas de integridad','NA','Hacer descalificaciones, burlas o comentarios ofensivos de carácter sexista','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (40,'Reglas de integridad','NA','Denegar una licencia por embarazo, maternidad o paternidad por nacimiento o adopción','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (41,'Reglas de integridad','NA','Manifestar prejuicios de género','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (42,'Reglas de integridad','NA','Solicitar a colaboradores/as, compañeros/as o alumnado, vestir de cierta manera','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (43,'Reglas de integridad','NA','Exclusión para que la persona asista a eventos académicos, culturales o deportivos','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (44,'Reglas de integridad','NA','La negativa a trabajar con determinadas personas por cuestión o motivo de género','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (45,'Reglas de integridad','NA','Cualquier otra similar o análoga a las anteriores','NA','NA');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (46,'Tipos de violencia de género','Acoso y Hostigamiento sexual.','Miradas lascivas, gestos o comentarios obscenos, contacto físico innecesario.','NA','#5c38a5');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (47,'Tipos de violencia de género','Acoso y Hostigamiento sexual.','Insinuaciones, "bromas" o insultos de carácter sexual.','NA','#5c38a5');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (48,'Tipos de violencia de género','Acoso y Hostigamiento sexual.','Chantajes o propuestas de tipo sexual para obtener mejoras laborales o académicas.','NA','#5c38a5');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (49,'Tipos de violencia de género','Acoso y Hostigamiento sexual.','Acorralar o forzar a tener con tacto físico.','NA','#5c38a5');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (50,'Tipos de violencia de género','Acoso y Hostigamiento sexual.','Solicitar "citas" fuera del horario laboral o académico, entre otras.','NA','#5c38a5');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (51,'Tipos de violencia de género','Discriminación de género.','Comentarios o "chistes" machistas.','NA','#5272bf');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (52,'Tipos de violencia de género','Discriminación de género.','Expresiones y actitudes misóginas (que desprecian a las mujeres a lo femenino).','NA','#5272bf');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (53,'Tipos de violencia de género','Discriminación de género.','Comentarios sexistas sobre la apariencia.','NA','#5272bf');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (54,'Tipos de violencia de género','Discriminación de género.','Ignorar aportaciones, excluir, menospreciar el trabajo, conocimientos o habilidades o descalificarlos con argumentos o expresiones sexistas.','NA','#5272bf');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (55,'Tipos de violencia de género','Discriminación de género','Negar una licencia por embarazo, maternidad paternidad.','NA','#5272bf');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (56,'Tipos de violencia de género','Discriminación de género','Manifestar prejuicios de género y fomentar estereotipos de genéro, entre otras.','NA','#5272bf');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (57,'Tipos de violencia de género','Violencia digital de genéro','Amenazas, comentarios o insultos sexistas en redes sociales, correos electrónicos o cualquier plataforma web.','NA','#5ddba8');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (58,'Tipos de violencia de género','Violencia digital de genéro','Vulneración de datos e informacion privada motivada por razón de sexo, orientación sexual, identidad o expresión de género.','NA','#5ddba8');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (59,'Tipos de violencia de género','Violencia digital de genéro','Acosar u hostigar sexualmente a través del uso de mensajería instantánea, redes sociales u otros espacios/medios virtuales.','NA','#5ddba8');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (60,'Tipos de violencia de género','Violencia digital de genérico','Difusión de rumores de contenido sexual, así como el envío, solicitud o distribución de imágenes, textos, fotografías, audios o videos de contenido sexual sin consentimiento por cualquier red social o medio digital.','NA','#5ddba8');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (61,'Tipos de violencia de género','OSIEG','Exclusión de grupos de trabajo, espacios o actividades por ser parte de la población LGBTI+.','NA','#fada1c');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (62,'Tipos de violencia de género','OSIEG','Comentarios, "chistes", "bromas" o burlas derivadas de la orientación sexual, identidad y expresión de género de las personas.','NA','#fada1c');
INSERT INTO `Datos_herramientas` (`ID_herramientas`,`Herramienta`,`Categoria`,`Regla`,`Numero`,`Color`) VALUES (63,'Tipos de violencia de género','OSIEG','No reconocer la identidad de género de las personas.','NA','#fada1c');

INSERT INTO `Datos_denunciante`(`ID_denunciante`,`Nombre`,`P_apellido`,`S_apellido`,`F_nacimiento`,`Edad`,`Genero`,`Otro_genero`,`C_electronico`,`T_celular`,`T_fijo_ext`,`Domicilio`) VALUES (1,'Emmanuel','Rosado','Martínez','1993/03/24',15,'Masculino','','emergos12@gmail.com','5521991921','5552739937','calle 4, lote 7, manzana 2, c.p. 01160, alcaldia alvaro obregon, col. 1ra victoria');
INSERT INTO `Datos_tutor`(`ID_tutor`,`ID_denunciante`,`Nombre_completo`,`Edad_t`,`Genero_t`,`Otro_genero_t`,`T_celular_t`,`T_fijo_ext_t`,`Domicilio_t`,`C_electronico_t`) VALUES ('1','1','Emmanuel Rosado Martínez',19,'Prefiero no decirlo','','5521991921','5552739937','calle siempre viva 123','america_ema13@hotmail.com');
INSERT INTO `Datos_hechos`(`ID_hechos`,`ID_denunciante`,`Anonimo`,`F_denuncia`,`H_denuncia`,`F_hechos`,`H_hechos`,`Lugar`,`Descripcion_hechos`) VALUES (1,1,'','2021/04/01','18:27','2021/03/31','18:27','sendero seguro','prueba de una denuncias');
INSERT INTO `Datos_academicos`(`ID_academico`,`ID_denunciante`,`ID_hechos`,`UA_DEP`,`Turno`,`Perfil`,`Numero_boleta`,`Semestre`,`Grupo`,`Carrera`,`Numero_empleado`,`Nombre_superior`,`Descripcion`) VALUES (1,1,1,'2385','Matutino','Funcionario(a)','','','','','2012630399','ninguno','');
INSERT INTO `Datos_denunciado`(`ID_denunciado`,`ID_denunciante`,`ID_hechos`,`Nombre_d`,`UA_DEP_d`,`Turno_d`,`Perfil_d`,`Semestre_d`,`Grupo_d`,`Carrera_d`,`Puesto_d`,`Nombre_superior_d`) VALUES (1,1,1,'Emmanuel Rosado Martínez','2385','Matutino','Docente','','','','ninguno','ninguno');
INSERT INTO `Datos_denunciado`(`ID_denunciado`,`ID_denunciante`,`ID_hechos`,`Nombre_d`,`UA_DEP_d`,`Turno_d`,`Perfil_d`,`Semestre_d`,`Grupo_d`,`Carrera_d`,`Puesto_d`,`Nombre_superior_d`) VALUES (2,1,1,'denunciado2','2385','Matutino','Docente','','','','ninguno','ninguno');
INSERT INTO `Datos_testigo`(`ID_testigo`,`ID_denunciante`,`ID_hechos`,`Nombre_te`,`C_electronico_te`,`T_celular_te`,`T_fijo_ext_te`) VALUES (1,1,1,'Emmnauel Rosado Martínez','emergos12@gmail.com','5521991921','5552739937');
INSERT INTO `Datos_testigo`(`ID_testigo`,`ID_denunciante`,`ID_hechos`,`Nombre_te`,`C_electronico_te`,`T_celular_te`,`T_fijo_ext_te`) VALUES (2,1,1,'testigo2','emergos12@gmail.com','5521991921','5552739937');
INSERT INTO `Datos_pruebas`(`ID_pruebas`,`ID_denunciante`,`ID_hechos`,`Denuncia`,`Lista_evidencias`,`Archivos`,`Direccion_elec`) VALUES (1,1,1,'on','prueba.txt pleca-ipn.png','archivos/1/1/prueba.txt archivos/1/1/pleca-ipn.png','www.ejemplo.com');
INSERT INTO `Datos_clasificacion`(`ID_clasificacion`,`ID_hechos`,`ID_herramientas`,`Validacion`,`Jaccard`,`Naive_bayes`,`Shallow`,`S_NN`) VALUES (1,1,1,0.45,0.45,0.35,0.20,0.10);
INSERT INTO `Datos_analisis`(`ID_analisis`,`ID_hechos`,`ID_usuario`,`ID_clasificacion`,`Estado`,`Confirmacion`,`Comentarios`) VALUES (1,1,1,1,'Analisis','Si','ninguno');

/*
CREATE VIEW [Login] AS SELECT `Datos_empleado.C_electronico,Datos_usuario.Contrasena,Datos_usuario.Perfil` 
FROM `Datos_empleado,Datos_usuario` WHERE 'Datos_empleado.ID_empleado=Datos_usuario.Cuenta';

CREATE VIEW [Datos_denunciante Datos_academicos Datos_tutor Datos_hechos Datos_denunciado Datos_testigo Datos_pruebas]

CREATE VIEW [Datos_herramientas] AS SELECT `Datos_herramientas.ID_herramientas,Datos_herramientas.Herramienta,Datos_herramientas.Regla,Datos_herramientas.Color`
FROM `Datos_herramientas` WHERE `Datos_herramientas.Color<>'NA' AND Datos_herramientas.Numero<>'NA'`;

create view `D_denuncia`as
select Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido,Datos_denunciante.F_nacimiento,Datos_denunciante.Edad,Datos_denunciante.Genero,Datos_denunciante.Otro_genero,Datos_denunciante.C_electronico,Datos_denunciante.T_celular,Datos_denunciante.T_fijo_ext,Datos_denunciante.Domicilio,
Datos_academicos.UA_DEP,Datos_academicos.Turno,Datos_academicos.Perfil,Datos_academicos.Numero_boleta,Datos_academicos.Semestre,Datos_academicos.Grupo,Datos_academicos.Carrera,Datos_academicos.Numero_empleado,Datos_academicos.Nombre_superior,Datos_academicos.Descripcion,
Datos_tutor.Nombre_completo,Datos_tutor.Edad_t,Datos_tutor.Genero_t,Datos_tutor.T_celular_t,Datos_tutor.T_fijo_ext_t,Datos_tutor.Domicilio_t,Datos_tutor.C_electronico_t,
Datos_hechos.Anonimo,Datos_hechos.F_denuncia,Datos_hechos.H_denuncia,Datos_hechos.F_hechos,Datos_hechos.H_hechos,Datos_hechos.Lugar,Datos_hechos.Descripcion_hechos,
Datos_denunciado.Nombre_d,Datos_denunciado.UA_DEP_d,Datos_denunciado.Turno_d,Datos_denunciado.Perfil_d,Datos_denunciado.Semestre_d,Datos_denunciado.Grupo_d,Datos_denunciado.Carrera_d,Datos_denunciado.Puesto_d,Datos_denunciado.Nombre_superior_d,
Datos_testigo.Nombre_te,Datos_testigo.C_electronico_te,Datos_testigo.T_celular_te,Datos_testigo.T_fijo_ext_te,
Datos_pruebas.Denuncia,Datos_pruebas.Lista_evidencias,Datos_pruebas.Archivos,Datos_pruebas.Direccion_elec,
 Datos_hechos.ID_hechos,Datos_clasificacion.ID_clasificacion
from ((((((((Datos_hechos inner join Datos_analisis on Datos_hechos.ID_hechos=Datos_analisis.ID_hechos)
inner join Datos_clasificacion on Datos_hechos.ID_hechos=Datos_clasificacion.ID_hechos)
inner join Datos_pruebas on Datos_hechos.ID_hechos=Datos_pruebas.ID_hechos)
inner join Datos_denunciado on Datos_hechos.ID_hechos=Datos_denunciado.ID_hechos)
inner join Datos_testigo on Datos_hechos.ID_hechos=Datos_testigo.ID_hechos)
inner join Datos_denunciante on Datos_hechos.ID_denunciante=Datos_denunciante.ID_denunciante)
inner join Datos_academicos on Datos_denunciante.ID_denunciante=Datos_academicos.ID_denunciante)
inner join Datos_tutor on Datos_denunciante.ID_denunciante=Datos_tutor.ID_denunciante);

folio,ua,fecha de la denuncia,hora de la denuncia,estado,folio

create or replace view `Denuncia` as
select Datos_hechos.ID_hechos,Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido, Datos_denunciado.Nombre_d,Datos_denunciado.UA_DEP_d,Datos_hechos.F_denuncia,Datos_hechos.H_denuncia,Datos_clasificacion.ID_herramientas,Datos_clasificacion.Naive_bayes,Datos_herramientas.Herramienta,Datos_herramientas.Color,Datos_analisis.Estado
from (((((Datos_hechos inner join Datos_denunciante on Datos_hechos.ID_denunciante=Datos_denunciante.ID_denunciante)
inner join Datos_denunciado on Datos_hechos.ID_hechos=Datos_denunciado.ID_hechos)
inner join Datos_clasificacion on Datos_hechos.ID_hechos=Datos_clasificacion.ID_hechos)
inner join Datos_herramientas on Datos_clasificacion.ID_herramientas=Datos_herramientas.ID_herramientas)
inner join Datos_analisis on Datos_hechos.ID_hechos=Datos_analisis.ID_hechos);

create or replace view `Datos` as
select Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido,Datos_denunciante.F_nacimiento,Datos_denunciante.Edad,Datos_denunciante.Genero,Datos_denunciante.Otro_genero,Datos_denunciante.C_electronico,Datos_denunciante.T_celular,Datos_denunciante.T_fijo_ext,Datos_denunciante.Domicilio,Datos_academicos.UA_DEP,Datos_academicos.Turno,Datos_academicos.Perfil,Datos_academicos.Numero_boleta,Datos_academicos.Semestre,Datos_academicos.Grupo,Datos_academicos.Carrera,Datos_academicos.Numero_empleado,Datos_academicos.Nombre_superior,Datos_academicos.Descripcion,Datos_tutor.Nombre_completo,Datos_tutor.Edad_t,Datos_tutor.Genero_t,Datos_tutor.T_celular_t,Datos_tutor.T_fijo_ext_t,Datos_tutor.Domicilio_t,Datos_tutor.C_electronico_t,Datos_hechos.ID_hechos
from (((Datos_hechos inner join Datos_denunciante on Datos_hechos.ID_denunciante=Datos_denunciante.ID_denunciante)
inner join Datos_academicos on Datos_denunciante.ID_denunciante=Datos_academicos.ID_denunciante)
inner join Datos_tutor on Datos_denunciante.ID_denunciante=Datos_tutor.ID_denunciante);

SELECT Datos_denunciante.Nombre,Datos_denunciante.P_apellido,Datos_denunciante.S_apellido,Datos_denunciante.F_nacimiento,Datos_denunciante.Edad,Datos_denunciante.Genero,Datos_denunciante.Otro_genero,Datos_denunciante.C_electronico,Datos_denunciante.T_celular,Datos_denunciante.T_fijo_ext,Datos_denunciante.Domicilio,Datos_academicos.UA_DEP,Datos_academicos.Turno,Datos_academicos.Perfil,Datos_academicos.Numero_boleta,Datos_academicos.Semestre,Datos_academicos.Grupo,Datos_academicos.Carrera,Datos_academicos.Numero_empleado,Datos_academicos.Nombre_superior,Datos_academicos.Descripcion,Datos_tutor.Nombre_completo,Datos_tutor.Edad_t,Datos_tutor.Genero_t,Datos_tutor.T_celular_t,Datos_tutor.T_fijo_ext_t,Datos_tutor.Domicilio_t,Datos_tutor.C_electronico_t,Datos_hechos.ID_hechos FROM (((Datos_hechos INNER JOIN Datos_denunciante ON Datos_hechos.ID_denunciante=Datos_denunciante.ID_denunciante) INNER JOIN Datos_academicos ON Datos_denunciante.ID_denunciante=Datos_academicos.ID_denunciante) INNER JOIN Datos_tutor ON Datos_denunciante.ID_denunciante=Datos_tutor.ID_denunciante) 
*/
