CREATE DATABASE IF NOT EXISTS BD_TT;
USE BD_TT;
/*Datos personales*/
CREATE TABLE IF NOT EXISTS `Datos_denunciante` (
    `ID_usuario`  INT UNSIGNED AUTO_INCREMENT,
    `Nombre` varchar(50),
    `P_paterno` varchar(50),
    `S_materno` varchar(50),
    `ID_institucional` INT UNSIGNED,
    `C_electronico` varchar(254),
    `Contrasena` varchar(127),
    `Perfil` varchar(15),
    `UA_DEP` varchar(256),
    PRIMARY KEY (`ID_usuario`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
/*Datos profesionales*/
CREATE TABLE IF NOT EXISTS `D_personal` (
    `Folio` INT UNSIGNED AUTO_INCREMENT,
    `ID_usuario` INT UNSIGNED,
    `F_denuncia` DATE,
    `H_denuncia` TIME,
    `F_nacimiento` DATE,
    `Edad` TINYINT UNSIGNED,
    `Genero` varchar(20),
    `Gen_desc` varchar(15),
    `Domicilio` TEXT,
    `T_celular` varchar(10),
    `T_fijo` varchar(10),
    `T_ext` varchar(15),
    `Anonima` varchar(2),
    PRIMARY KEY (`Folio`),
    FOREIGN KEY (`ID_usuario`) REFERENCES `Usuario`(`ID_usuario`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `E_usuario` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `ID_usuario` INT UNSIGNED,
    `F_actual` DATE,
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`ID_usuario`) REFERENCES `Usuario`(`ID_usuario`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

/*
CREATE TABLE IF NOT EXISTS `D_tareas` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `ID_usuario` INT UNSIGNED,
    `ID_institucional` INT UNSIGNED,
    `Folio` INT UNSIGNED,
    `Actividad` varchar(100),
    `Edo_actividad` varchar(15),
    `Descripcion` TEXT,
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`),
    FOREIGN KEY (`ID_usuario`) REFERENCES `Usuario`(`ID_usuario`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
*/
CREATE TABLE IF NOT EXISTS `DD_sp` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Puesto` varchar(50),
    `Jefa_o` varchar(100),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_clasificion` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Pd_denuncia` tinyint,
    `IS_jaccard` float(24),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_testigos` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Nombre` varchar(50),
    `A_paterno` varchar(50),
    `A_materno` varchar(50),
    `T_fijo_cel` varchar(10),
    `T_ext` varchar(15),
    `C_electronico` varchar(254),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_trabajador` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `F_actual` varchar(50),
    `T_contrato` varchar(50),
    `Jefa_o` varchar(100),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_hechos` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `F_hechos` DATE,
    `H_hechos` TIME,
    `Lugar` varchar(200),
    `Descripcion` TEXT,
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `DD_alumno` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Carrera` varchar(150),
    `Semestre` varchar(3),
    `Grupo` varchar(10),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_alumno` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Carrera` varchar(150),
    `Semestre` varchar(3),
    `Turno` varchar(11),
    `Grupo` varchar(10),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_profesional` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Perfil` varchar(15),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `A_tutor` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Nombre` varchar(50),
    `A_paterno` varchar(50),
    `A_materno` varchar(50),
    `Edad` TINYINT UNSIGNED,
    `Genero` varchar(20),
    `Domicilio` TEXT,
    `Telefono` varchar(10),
    `C_electronico` varchar(254),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_denunciado` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `Nombre` varchar(50),
    `A_paterno` varchar(50),
    `A_materno` varchar(50),
    `Dependencia` varchar(105),
    `Turno` varchar(11),
    `Perfil` varchar(15),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;

CREATE TABLE IF NOT EXISTS `D_archivos` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `M_probatorio` varchar(2),
    `Pruebas` TEXT,
    `D_pruebas` varchar(2048),
    `L_pruebas` varchar(2048),
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
/*
CREATE TABLE IF NOT EXISTS `Agenda` (
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Folio` INT UNSIGNED,
    `ID_usuario` INT UNSIGNED,
    `ID_institucional` INT UNSIGNED,
    `C_electronico` varchar(254),
    `Titulo` varchar(50),
    `F_reunion` DATE,
    `H_reunion` TIME,
    `Ubicacion` varchar(50),
    `Descripcion` TEXT,
    PRIMARY KEY (`ID`),
    FOREIGN KEY (`Folio`) REFERENCES `D_personal`(`Folio`),
    FOREIGN KEY (`ID_usuario`) REFERENCES `Usuario`(`ID_usuario`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
*/
CREATE TABLE IF NOT EXISTS `Herramientas`(
    `ID` INT UNSIGNED AUTO_INCREMENT,
    `Nombre_h` varchar(256),
    `Regla` varchar(256),
    `Numero` SMALLINT UNSIGNED,
    `Color` varchar(256),
    PRIMARY KEY (`ID`)
)CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
/*TEXT*/

INSERT INTO `Usuario`( `Nombre`,`A_paterno`,`A_materno`,`ID_institucional`,`C_electronico`,`Contrasena`,`Perfil`,`UA_DEP`) 
VALUES ("Emmanuel","Rosado","Martinez",2012630399,"emergos12@gmail.com","12345678","Trabajador","ESCOM");

INSERT INTO `Herramientas`(`Nombre_h`,`Regla`,`Numero`,`Color`) 
VALUES ("RI1","Uso y exhibición de materiales de carácter sexual fuera del
ámbito académico",0,"Morado");