import re

from flask_wtf import FlaskForm
from wtforms import Form
from wtforms.fields import PasswordField,SubmitField,IntegerField,StringField,TextAreaField,SelectField,DecimalField,RadioField,FloatField
from wtforms.fields.html5 import EmailField,DateField,TimeField
from wtforms import validators

"""
def validacion(form,field):
    cadena=field.data.split()
    error=""
    if(len(cadena)==1):
        
    elif(len(cadena)>1):
        error="El campo no debe estar vacio"

def car_rep(cadena):
    for i in len(cadena):
"""

def texto(form,field):
    error=""
    if(len(field.data)<2 or len(field.data)>50):
        error="La longitud del campo no es valida"
    elif(len(re.findall('[0-9]',field.data))>0):
        error="El campo no puede contener numeros"
    elif(len(re.findall('["!·$%&/()-=?¿^*¨Ç;:_><,.´+`¡@`+]',field.data))>0):
        error="El campo no puede contener signos de puntuacion"
    raise validators.ValidationError(error)
    
def numero(form,field):
    pass

#crear clases para conjunto de formularios para que no se sobre cargue el sistema
class FormBuilder(Form):
    den_nombre=StringField('Nombre(s)',[
        validators.InputRequired(message="Campo requerido"),
        texto
        ])
    den_p_apellido=(StringField('Primer apellido',[
        validators.InputRequired(message="Campo requerido"),
        validators.length(min=2,max=50,message="Longitud del campo invalida"),
        validators.Regexp("[a-zA-Z]",message="El apellido solo puede contener letras")
        ]))
    den_s_apellido=(StringField('Segundo apellido',[
        validators.length(min=2,max=50,message="Longitud del campo invalida"),
        validators.Regexp("[a-zA-Z]",message="El apellido solo puede contener letras")
        ]))
    den_f_nacimiento=DateField('Fecha de nacimiento',[
        validators.InputRequired("Fecha requerido")
        ])
    den_edad=DecimalField('Edad',[
        validators.InputRequired(message="La edad es requerida"),
        validators.NumberRange(min=14,max=110,message="La edad solo puede estar entre 14 y 110")
        ])
    den_genero=SelectField('Genero',choices=[('Femenino','Femenino'),('Masculino','Masculino'),('Prefiero no decirlo','Prefiero no decirlo'),('Otro','Otro')])
    den_o_genero=StringField('Describa',[validators.Regexp("[a-zA-Z]",message="La descripcion solo puede contener letras")])
    den_correo=EmailField('Correo electronico',[
        validators.InputRequired(message="Correo electronico requerido"),
        validators.Regexp("[a-zA-Z]@[a-zA-Z].[a-zA-Z]",message="El formato del correo electronico es @.dominio")
        ])
    den_t_celular=StringField('Telefono celular',[
        validators.InputRequired(message="Campo requerido"),
        validators.NumberRange(min=10,max=10,message="Numero de telefono incorrecto"),
        validators.Regexp("[0-9]{10}",message="El telefono solo debe contiener numeros")
        ])
    den_t_fijo=StringField('Telefono fijo/extencion (si existe)',[
        validators.Regexp("[0-9]{10}(/[0-9]{4,15})?",message="El telefono debe tener el siguiente formato: 1234567890/123456"),
        validators.length(min=10,max=26,message="El telefono tiene una longitud invalida")
        ])
    den_domicilio=TextAreaField('Domicilio',[
        validators.Regexp("[a-zA-z0-9.,/]",message="El domicilio puede tener letras, numeros y /,.")
        ])
    #aca_id_denunciante
    aca_ua_dep=SelectField("Unidad academica",choices=[('Escuela Superior de Computo','Escuela Superior de Computo')])
    aca_turno=SelectField("Turno",choices=[('Matutino','Matutino'),('Vespertino','Vespertino'),('Mixto','Mixto')])
    aca_perfil=SelectField('Perfil',choices=[('Alumno(a)','Alumno(a)'),('Docente','Docente'),('PAAE','PAAE'),('Funcionario(a)','Funcionario(a)'),('Otro','Otro')])
    aca_no_boleta=IntegerField('No. boleta',[
        validators.InputRequired(message="La boleta es requerida"),
        validators.NumberRange(min=10,max=10,message="La boleta solo debe contener 10 digitos")
        ])
    aca_semestre=IntegerField('Semestre',[
        validators.Regexp("[0-9]{1,2}",message="Solo pueden ser numeros"),
        validators.length(min=1,max=2,message="El campo solo puede tener 2 digitos")
        ])
    aca_grupo=StringField('Grupo')
    aca_carera=StringField('Carrera',[
        validators.Regexp("[a-zA-Z.]",message="El campo solo puede tener texto")
        ])
    aca_no_empleado=IntegerField('No. empleado',[
        validators.InputRequired(message="El numero de empleado es requerido")
        ])
    aca_nombre_jefe=StringField('Nombre de la o el Jefe(a)',[
        validators.Regexp("[a-zA-Z]",message="El nombre solo debe dcontener letras")
        ])
    aca_otro=StringField('Descripcion',[
        validators.Regexp("[a-zA-Z]",message="la descripcion solo debe dcontener letras")
        ])
    #tutor_id_denunciante
    tutor_nombre=StringField('Nombre completo',[
        validators.InputRequired(message="El nombre completo es obligatorio"),
        validators.Regexp("[a-zA-Z]",message="El nombre completo solo debe tener letras"),
        validators.length(min=50,max=200,message="La longitud es invalida")
        ])
    tutor_edad=DecimalField('Edad',[
        validators.InputRequired(),
        validators.NumberRange(min=18,max=110,message="La edad debe estar entre 18 y 110 años")
        ])
    tutor_genero=SelectField('Genero',choices=[('Femenino','Femenino'),('Masculino','Masculino'),('Prefiero no decirlo','Prefiero no decirlo'),('Otro','Otro')])
    tutor_o_genero=StringField('Describa',[
        validators.Regexp("[a-zA-Z]",message="La descripcion solo debe tener letras")
        ])
    tutor_t_celular=StringField('Telefono celular',[
        validators.Regexp("[0-9]{10}",message="El celular solo debe contener numeros")
        ])
    tutor_t_fijo=StringField('Telefono fijo/extencion (si existe)',[
        validators.Regexp("[0-9]{10}(/[0-9]{4,15})?",message="El telefono debe tener este formato: 123456789/1234")
        ])
    tutor_domicilio=TextAreaField('Domicilio',[
        validators.Regexp("[a-zA-Z]",message="El domicilio solo puede tener letras")
        ])
    tutor_correo=EmailField('Correo electronico',[
        validators.Regexp("[a-zA-Z0-9]@[a-z].[a-z]",message="El formato del correo electronico es: asd123@asd.dominio")
        ])
    #he_id_denunciante
    hechos_anonima=RadioField('¿Desea que su denuncia se anonima?',choices=[('Si','Si'),('No','No')])
    hechos_f_denuncia=DateField('Fecha de la denuncia')#ponen en servidor
    hechos_h_denuncia=TimeField('Hora de la denuncia')#ponen en servidor
    hechos_f_hechos=DateField('Fecha de los hechos',[
        validators.InputRequired(message="La fecha de los hechos es requerida")
        ])
    hechos_h_hechos=TimeField('Hora de los hechos',[
        validators.InputRequired(message="La hora aproximada de lo hechos es requerida")
        ])
    hechos_lugar=TextAreaField('Lugar de los hechos',[
        validators.InputRequired(message="El lugar es requerido"),
        validators.Regexp("[a-zA-Z0-9,.]",message="El lugar solo puede tener letras, numeros, comas y puntos")
        ])
    hechos_descripcion=TextAreaField('Descripcion de los hechos',[
        validators.InputRequired(message="La descripcion es requerida"),
        validators.Regexp("[a-zA-Z0-9.,]",message="La descripcion solo puede tener letras, numeros, comas y puntos")
        ])
    #d_id_denunciante
    #d_id_hechos
    d_nombre=StringField('Nombre(s)',[
        validators.Regexp("[a-zA-Z]",message="El nombre solo puede contener letras")
        ])
    d_p_apellido=StringField('Primer apellido',[
        validators.Regexp("[a-zA-Z]",message="El apellido solo puede contener letras")
        ])
    d_s_apellio=StringField('Segundo apellido',[
        validators.Regexp("[a-zA-Z]",message="El apellido solo puete contener letras")
        ])
    d_ua_dep=SelectField("Unidad academica",choices=[('Escuela Superior de Computo','Escuela Superior de Computo')])
    d_turno=SelectField("Turno",choices=[('Matutino','Matutino'),('Vespertino','Vespertino'),('Mixto','Mixto')])
    d_perfil=SelectField('Perfil',choices=[('Alumno(a)','Alumno(a)'),('Docente','Docente'),('PAAE','PAAE'),('Funcionario(a)','Funcionario(a)'),('Otro','Otro')])
    d_semestre=IntegerField('Semestre',[
        validators.Regexp("[0-9]{1,2}",message="Solo pueden ser numeros"),
        validators.length(min=1,max=2,message="El campo solo puede tener 2 digitos")
        ])
    d_grupo=StringField('Grupo')
    d_carrera=StringField('Carrera',[
        validators.Regexp("[a-zA-Z.]",message="El campo solo puede tener texto")
        ])
    d_puesto=StringField('Puesto')
    d_nombre_jefe=StringField('Nombre de la o el jefe',[
        validators.Regexp("[a-zA-Z]",message="El nombre solo debe dcontener letras")
        ])
    #testigo_id_denunciante
    #testigo_id_hechos
    testigo_nombre=StringField('Nombre(s)',[texto])
    testigo_p_apellido=StringField('Primer apellido',[texto])
    testigo_s_apellido=StringField('Segundo apellido',[texto])
    testigo_correo=EmailField('Correo electronico')
    testigo_t_celular=StringField('Telefono celular')
    testigo_t_fijo=StringField('Telefono fijo/extencion (si existe)')
    #pruebas_id_denuncia
    #pruebas_id_hechos
    pruebas_denuncia=RadioField('¿Desea agregar pruebas?',choices=[('Si','Si'),('No','No')])
    pruebas_l_evidencias=TextAreaField('Liste sus evidencias')
    pruebas_archivos=StringField('Archivos')
    pruebas_d_electronica=StringField('Escriba la direccion electronica del lugar donde se encuentran las pruebas')
    #val_id_hechos
    #val_numero
    #clas_id_hechos
    #clas_jaccard
    #clas_russel_rao
    #clas_dice
    #clas_sokal_sneath
    emp_nombre=StringField('Nombre(s)',[
        validators.InputRequired(message="El nombre es requerido"),
        texto
        ])
    emp_p_apellido=StringField('Primer apellido',[
        validators.InputRequired(message="El apellido es requerido"),
        texto
        ])
    emp_s_apellido=StringField('Segundo apellido',[
        validators.InputRequired(message="El apellido es requerido"),
        texto
        ])
    emp_no_empleado=DecimalField('Numero de empleado',[
        validators.InputRequired(message="El numero de empleado es requerido")
        ])
    emp_correo=EmailField('Correo electronico')
    #usua_cuenta
    usua_contrasena=PasswordField('Contraseña',[
        validators.InputRequired(message="La contraseña es requerida"),
        validators.length(min=8)
        ])
    usua_perfil=SelectField('Perfil',choices=[('Trabajador','Trabajador'),('Administrador de usuarios','Administrador de usuarios'),('Administrador de herramientas','Administrador de herramientas')])
    #ana_id_hechos
    #ana_id_usuario
    #ana_id_clasificacion
    ana_estado=SelectField('Perfil',choices=[('Inicio','Inicio'),('Analisis','Analisis'),('Procesando','Procesando'),('Terminado','Terminado')])
    ana_confirmacion=RadioField('¿La denuncia previa concuerda con la entrevista?',choices=[('Si','Si'),('No','No')])
    ana_comentarios=TextAreaField('Comentarios',[
        validators.Regexp("[a-zA-Z,.]",message="Los comentarios solo pueden tener letras, comas y puntos.")
        ])
    #herr_id_usuario
    herr_herramienta=StringField('Nombre de la herramienta',[
        validators.InputRequired(message="El nombre de la herramienta digital/documento es requerido"),
        validators.Regexp("[a-zA-Z]",message="El nombre solo puede tener letras")
        ])
    herr_categoria=StringField('Titulo de la categoria',[
        validators.InputRequired(message="El titulo es requerido"),
        validators.Regexp("[a-zA-Z]",message="La categoria solo puede tener letras")
        ])
    herr_regla=StringField('Descripcion',[
        validators.InputRequired(message="La descripcion es requerida"),
        validators.Regexp("[a-zA-Z.,]",message="La descripcion solo puede tener letras, puntos y comas")
        ])
    herr_numero=DecimalField('Numero de la regla (si no aplica utilice "na")',[
        validators.Regexp("([0-9])|na",message='El numero solo debe tener numeros o "na"(no aplica)')
        ])
    herr_color=StringField('Color de la regla (hexadecimal)',[
        validators.Regexp("#[A-F0-9]",message="El color debe estar en hexadecimal")
        ])
    #botones
    registrar=SubmitField('Registrar')
    eliminar=SubmitField('Eliminar')
    actualizar=SubmitField('Actualizar')
    acceder=SubmitField('Acceder')

    """
    correo=EmailField('Correo electronico')
    contrasena=PasswordField('Contraseña')
    id_institucional_t=IntegerField('No. empleado')#describir a un empleado
    id_institucional_e=IntegerField('No. boleta')#describir a un alumno/a
    id_institucional=IntegerField('No. boleta/empleado')#cuestionario de una denuncia
    folio=IntegerField('Folio')
    actividad=StringField('Actividad')
    descripcion=TextAreaField('Descripcion')
    id_usuario=IntegerField('Id usuario')
    nombre=StringField('Nombre')
    m_apellido=StringField("Apellido materno")
    p_apellido=StringField("Apellido paterno")
    titulo=StringField('Titulo de la reunion')
    f_reunion=DateField("Fecha de la reunion")#año-mes-dia
    h_reunion=TimeField("Hora de la reunion")
    ubicacion=StringField('Ubicacion')
    f_denuncia=DateField('Fecha de la denuncia')
    h_denuncia=TimeField('hora de la denuncia')
    f_nacimiento=DateField('Fecha de nacimiento')
    edad=DecimalField('Edad')
    gen_desc=StringField('Describa')
    domicilio=TextAreaField('Domicilio')
    t_celular=StringField('Telefono celular')
    t_fijo=StringField('Telefono fijo')
    t_ext=DecimalField('Extension')
    pd_denuncia=DecimalField('Pesos de los datos')
    is_jaccard=FloatField('Indice de Jaccard')
    sp_puesto=StringField('Puesto')
    sp_jefao=StringField('Nombre del jefe inmediato')
    te_nombre=StringField('Nombre del testigo')
    te_a_paterno=StringField('Apellido paterno')
    te_a_materno=StringField('Apellido materno')
    te_t_fijo_celular=StringField('Telefono fijo/celular')
    te_t_ext=StringField('Extension')
    te_c_electronico=EmailField('Correo electronico')
    tr_f_actual=StringField('Funcion actual')
    tr_t_contrato=StringField('Tipo de contrato')
    tr_jefa_o=StringField('Superior inmediato')
    h_f_hechos=DateField('Fecha del incidente')
    h_h_hechos=TimeField('Hora del incidente')
    h_lugar=StringField('Lugar del incidente')
    h_descripcion=TextAreaField('Descripcion de los hechos')
    her_nombre_h=StringField('Nombre de la herramienta')
    her_regla=StringField('Regla')
    her_numero=DecimalField('Numero de regla')
    her_color=StringField('Color de la regla')
    dd_alumno
    anonima=RadioField('¿Desea que su denuncia se anonima?',choices=[('Si','Si'),('No','No')])
    edo_actividad=SelectField('Estado',choices=[('Analizando','Analizando'),('Procesando','Procesando'),('Ejecutando','Ejecutando'),('Terminado','Terminado')])
    perfil=SelectField('Perfil',choices=[('Alumno/a','Alumno/a'),('Docente','Docente'),('PAAE','PAAE'),('Funcionario/a','Funcionario/a'),('Otro','Otro')])
    genero=SelectField('Genero',choices=[('Femenino','Femenino'),('Masculino','Masculino'),('Prefiero no decirlo','Prefiero no decirlo'),('Otro','Otro')])
    ua_dep=SelectField("Unidad academica",choices=[('Escuela Superior de Computo','Escuela Superior de Computo')])
    dependencia=SelectField("Dependencia Politécnica",choices=[('Unidad Politécnica de Gestión con Perspectiva de Género','Unidad Politécnica de Gestión con Perspectiva de Género')])
    e_f_actual=SelectField('Perfil',choices=[('Trabajador','Trabajador'),('Gestor de informacion','Gestor de informacion')])
    registrar=SubmitField('Registrar')
    eliminar=SubmitField('Eliminar')
    actualizar=SubmitField('Actualizar')
    acceder=SubmitField('Acceder')
    """